=== Massic Integration ===
Contributors: massic1
Tags: cms, content, publishing, api, seo
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Secure WordPress integration for Massic pairing, publishing, previews, and SEO metadata. Requires a Massic account.

== Description ==
Massic Integration links your WordPress site to Massic so authorized users can publish, preview, update, and unpublish WordPress posts/pages from Massic with signed requests.

This plugin requires an active Massic account and a connection to Massic services. After an administrator connects the plugin, Massic can send authorized publishing requests to this WordPress site.

Key features:

* One-click connect flow from WP Admin with secure pairing.
* Signed REST endpoints for publish/update, unpublish, preview link creation, slug checks, and theme checks.
* Draft and publish support for posts and pages.
* Structured SEO head payload storage and rendering on singular content.
* Best-effort lifecycle sync on plugin deactivate/uninstall.

Security model:

* Requests are verified with HMAC signatures, nonce, and timestamp checks.
* Site-scoped identifiers and secrets are required for privileged operations.
* Content writes are constrained to `post` and `page` post types.

== External services ==
This plugin connects to external Massic services to complete pairing and content publishing workflows.

1. Massic Backend API (`MASSIC_BACKEND_BASE`, default `https://agency.massic.io`)
* What it is used for: one-click pairing, connection approval, signed connector requests, publishing operations, lifecycle sync, and connector support.
* What data is sent from WordPress to Massic: site URL, site ID, site name, connection state, signed request metadata, plugin lifecycle events, theme/style information, logo or site icon URLs, sample post/page URLs, template availability, connector status details, WordPress post/page IDs, slugs, permalinks, and publishing status.
* What data is sent from Massic to WordPress: content titles, slugs, statuses, HTML content, excerpts, publish dates, SEO/head metadata, featured image URLs and metadata, preview requests, slug availability checks, page template checks, unpublish requests, and disconnect requests.
* When data is sent: when an administrator starts or approves connection, when Massic publishes/previews/updates/unpublishes content, when Massic checks theme or slug state, and during best-effort deactivate/uninstall lifecycle sync.

2. Massic App (`MASSIC_APP_BASE`, default `https://app.massic.io`)
* What it is used for: Massic account login and the one-click approval flow initiated from WP Admin.
* What data is sent: site URL, site ID, state token, finalize token, return URL, and connect-session identifiers needed for approval.
* When data is sent: when an admin starts the recommended connect flow.

Publisher links:
* Terms: https://massic.io/terms
* Privacy policy: https://massic.io/privacy

== Installation ==
1. Install and activate Massic Integration from Plugins > Add New in WP Admin.
2. Go to Settings > Massic Integration.
3. Review the service disclosure and confirm you have authority to connect this WordPress site to Massic.
4. Click Connect to Massic (Recommended) and complete approval in your Massic account.
5. Return to WP Admin and verify the connector shows Connected.

Production defaults:
* `MASSIC_BACKEND_BASE`: `https://agency.massic.io`
* `MASSIC_APP_BASE`: `https://app.massic.io`

Developers may override service endpoints with constants or environment variables when testing non-public builds:
* `wp-config.php`: `define('MASSIC_BACKEND_BASE', 'https://your-backend.example');`
* `wp-config.php`: `define('MASSIC_APP_BASE', 'https://your-app.example');`

Manual fallback:
* Expand `Manual setup (Advanced)` and use Site ID / Pairing Code / Client Secret.

== Frequently Asked Questions ==
= Does this plugin affect non-Massic pages? =
No. The plugin does not globally enqueue front-end styles for the site and only writes content for posts/pages published through Massic.

= What can Massic do after I connect? =
Massic can send signed requests to create, update, preview, unpublish, and check standard WordPress posts and pages. Requests are verified with site-scoped HMAC credentials, timestamps, and nonce replay protection.

= Does Massic create WordPress media? =
Yes. If Massic sends a featured image reference for published content, the plugin can download the image from a Massic-hosted or CDN URL and import it into the WordPress media library.

= Does page publishing require a specific template? =
No. Pages publish using your theme's default page template. If your active theme includes a page template named `Massic Template`, the plugin assigns it automatically for the most consistent layout, but it is not required. Within the Massic app you can choose to publish only to `Massic Template` pages.

= What happens if I deactivate or remove the plugin? =
Previously published content remains in WordPress. Posts, pages, imported media, stored SEO metadata, and Massic post metadata are not deleted automatically. On deactivate/uninstall, the plugin sends a best-effort lifecycle notice to Massic so the remote connection can be revoked.

= Which post types are supported? =
The connector only writes to standard WordPress `post` and `page` types.

= Can I keep using manual WordPress editing? =
Yes. Standard WordPress editing remains available. The connector only handles signed Massic publish actions.

== Screenshots ==
1. Settings > Massic Integration screen with connect controls.
2. Connected state with Site ID and connection status.
3. Manual setup section with pairing details.

== Changelog ==
= 1.0.0 =
* Initial public release.
* Secure connect/disconnect flow with signed requests.
* Signed content upsert/unpublish/preview-link endpoints.
* Structured SEO head metadata rendering.

== Upgrade Notice ==
= 1.0.0 =
Initial public release.
