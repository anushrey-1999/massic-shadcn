(function () {
    'use strict';

    var settings = window.massicAdmin || {};
    var copiedLabel = settings.copiedLabel || 'Copied';

    function copyValue(input, buttonEl) {
        var value = input.value || '';
        if (!value) {
            return;
        }

        function markCopied() {
            var original = buttonEl.getAttribute('data-massic-original-label');
            if (original === null) {
                original = buttonEl.textContent;
                buttonEl.setAttribute('data-massic-original-label', original);
            }
            buttonEl.textContent = copiedLabel;
            setTimeout(function () {
                buttonEl.textContent = original;
            }, 1200);
        }

        function fallbackCopy() {
            var originalType = input.type;
            if (originalType === 'password') {
                input.type = 'text';
            }
            input.select();
            try {
                document.execCommand('copy');
            } catch (e) {}
            if (originalType === 'password') {
                input.type = originalType;
            }
            markCopied();
        }

        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(value).then(markCopied).catch(fallbackCopy);
            return;
        }

        fallbackCopy();
    }

    document.addEventListener('click', function (event) {
        var buttonEl = event.target.closest('.massic-copy-button');
        if (!buttonEl) {
            return;
        }

        var targetId = buttonEl.getAttribute('data-massic-copy-target');
        if (!targetId) {
            return;
        }

        var input = document.getElementById(targetId);
        if (!input) {
            return;
        }

        event.preventDefault();
        copyValue(input, buttonEl);
    });
})();
