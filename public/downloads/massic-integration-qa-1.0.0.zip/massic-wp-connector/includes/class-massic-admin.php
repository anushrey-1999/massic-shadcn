<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Admin {
    const PAGE_SLUG = 'massic-integration';

    public function init() {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_post_massic_oauth_start', array($this, 'handle_oauth_start'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    }

    public function register_menu() {
        add_options_page(
            __('Massic Integration', 'massic-integration'),
            __('Massic Integration', 'massic-integration'),
            'manage_options',
            self::PAGE_SLUG,
            array($this, 'render_settings_page')
        );
    }

    public function enqueue_admin_assets($hook_suffix) {
        if ($hook_suffix !== 'settings_page_' . self::PAGE_SLUG) {
            return;
        }

        wp_enqueue_script(
            'massic-admin',
            MASSIC_WP_CONNECTOR_URL . 'assets/admin.js',
            array(),
            MASSIC_WP_CONNECTOR_VERSION,
            true
        );

        wp_localize_script('massic-admin', 'massicAdmin', array(
            'copiedLabel' => __('Copied', 'massic-integration'),
        ));
    }

    public function register_settings() {
        register_setting('massic_connector_group', Massic_Options::OPTION_SITE_ID, array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));

        register_setting('massic_connector_group', Massic_Options::OPTION_PAIRING_CODE, array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));

        register_setting('massic_connector_group', Massic_Options::OPTION_CLIENT_SECRET, array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));

        register_setting('massic_connector_group', Massic_Options::OPTION_NONCE_TTL, array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 300,
        ));
    }

    public function handle_oauth_start() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'massic-integration'));
        }

        check_admin_referer('massic_oauth_start');

        $backend_base = Massic_Options::get_backend_base();
        if (!$backend_base) {
            $this->redirect_with_notice(__('Connection is not available right now. Please contact support.', 'massic-integration'), 'error');
        }

        $backend_host = wp_parse_url($backend_base, PHP_URL_HOST);

        $site_id = Massic_Options::get_site_id();
        if (!$site_id) {
            $this->redirect_with_notice(__('Could not start connection. Please refresh and try again.', 'massic-integration'), 'error');
        }

        if (!Massic_Options::get_client_secret()) {
            Massic_Options::rotate_client_secret();
        }

        $state = wp_generate_password(40, false, false);
        $finalize_token = wp_generate_password(56, false, false);
        $return_url = admin_url('admin.php?page=' . self::PAGE_SLUG);

        Massic_Options::create_connect_session(
            $state,
            $finalize_token,
            $return_url,
            get_current_user_id()
        );

        $start_url = rtrim($backend_base, '/') . '/api/cms/wordpress/oauth/start';
        $redirect_url = add_query_arg(array(
            'siteUrl' => site_url(),
            'siteId' => $site_id,
            'state' => $state,
            'finalizeToken' => $finalize_token,
            'returnUrl' => $return_url,
        ), $start_url);

        add_filter('allowed_redirect_hosts', function($hosts) use ($backend_host) {
            $hosts[] = $backend_host;
            return array_values(array_unique(array_filter($hosts)));
        });

        wp_safe_redirect($redirect_url);
        exit;
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $connection_state = Massic_Options::get_connection_state();
        $connection_updated_at = Massic_Options::get_connection_updated_at();
        $connection_updated_at_readable = $this->format_datetime_for_admin($connection_updated_at);

        $notice_message = '';
        $notice_type = 'success';
        $notice_nonce = isset($_GET['_massic_notice_nonce']) ? sanitize_text_field(wp_unslash((string) $_GET['_massic_notice_nonce'])) : '';
        if ($notice_nonce && wp_verify_nonce($notice_nonce, 'massic_admin_notice')) {
            $notice_message = isset($_GET['massic_notice']) ? sanitize_text_field(wp_unslash((string) $_GET['massic_notice'])) : '';
            $notice_type = isset($_GET['massic_notice_type']) ? sanitize_text_field(wp_unslash((string) $_GET['massic_notice_type'])) : 'success';
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Massic Integration', 'massic-integration'); ?></h1>

            <?php if ($notice_message) : ?>
                <div class="notice <?php echo esc_attr($notice_type === 'error' ? 'notice-error' : 'notice-success'); ?> is-dismissible">
                    <p><?php echo esc_html($notice_message); ?></p>
                </div>
            <?php endif; ?>

            <div style="margin: 12px 0 18px; padding: 10px 12px; border: 1px solid #dcdcde; border-radius: 6px; background: #fff;">
                <p style="margin:0 0 4px;">
                    <strong><?php esc_html_e('Service disclosure:', 'massic-integration'); ?></strong>
                    <?php esc_html_e('This plugin requires a Massic account. Connecting sends site and content data to Massic so Massic can publish, preview, unpublish, and manage authorized WordPress content.', 'massic-integration'); ?>
                </p>
                <p style="margin:0; color:#646970;">
                    <a href="https://massic.io/terms" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Massic Terms', 'massic-integration'); ?></a>
                    &nbsp;|&nbsp;
                    <a href="https://massic.io/privacy" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Massic Privacy Policy', 'massic-integration'); ?></a>
                </p>
            </div>

            <div style="margin: 12px 0 18px; padding: 10px 12px; border: 1px solid #dcdcde; border-radius: 6px; background: #fff;">
                <p style="margin:0 0 4px;"><strong><?php esc_html_e('Connection Status:', 'massic-integration'); ?></strong>
                    <?php if ($connection_state === 'connected') : ?>
                        <span style="color:#008a20;"><?php esc_html_e('Connected', 'massic-integration'); ?></span>
                    <?php else : ?>
                        <span style="color:#646970;"><?php esc_html_e('Disconnected', 'massic-integration'); ?></span>
                    <?php endif; ?>
                </p>
                <?php if (!empty($connection_updated_at)) : ?>
                    <p style="margin:0; color:#646970;">
                        <strong><?php esc_html_e('Last Updated:', 'massic-integration'); ?></strong>
                        <span title="<?php echo esc_attr($connection_updated_at); ?>">
                            <?php echo esc_html($connection_updated_at_readable); ?>
                        </span>
                    </p>
                <?php endif; ?>
            </div>

            <h2><?php esc_html_e('Connect', 'massic-integration'); ?></h2>
            <?php if ($connection_state === 'connected') : ?>
                <div style="margin-bottom:18px; padding:10px 12px; border:1px solid #dcdcde; border-radius:6px; background:#f6f7f7;">
                    <p style="margin:0; color:#1d2327;"><strong><?php esc_html_e('Already connected.', 'massic-integration'); ?></strong> <?php esc_html_e('No further action is required.', 'massic-integration'); ?></p>
                </div>
            <?php else : ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:18px;">
                    <input type="hidden" name="action" value="massic_oauth_start" />
                    <?php wp_nonce_field('massic_oauth_start'); ?>
                    <button type="submit" class="button button-primary">
                        <?php esc_html_e('Connect to Massic (Recommended)', 'massic-integration'); ?>
                    </button>
                </form>
            <?php endif; ?>

            <details>
                <summary style="cursor:pointer;"><strong><?php esc_html_e('Manual Setup (Advanced)', 'massic-integration'); ?></strong></summary>
                <form method="post" action="options.php">
                    <?php settings_fields('massic_connector_group'); ?>
                    <?php do_settings_sections('massic_connector_group'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>"><?php esc_html_e('Site ID', 'massic-integration'); ?></label></th>
                            <td>
                                <input
                                    id="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>"
                                    name="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>"
                                    type="text"
                                    class="regular-text"
                                    value="<?php echo esc_attr(Massic_Options::get_site_id()); ?>"
                                />
                                <button
                                    type="button"
                                    class="button button-secondary massic-copy-button"
                                    style="margin-left:8px;"
                                    data-massic-copy-target="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>"
                                >
                                    <?php esc_html_e('Copy', 'massic-integration'); ?>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>"><?php esc_html_e('Pairing Code', 'massic-integration'); ?></label></th>
                            <td>
                                <input
                                    id="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>"
                                    name="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>"
                                    type="text"
                                    class="regular-text"
                                    value="<?php echo esc_attr(Massic_Options::get_pairing_code()); ?>"
                                />
                                <button
                                    type="button"
                                    class="button button-secondary massic-copy-button"
                                    style="margin-left:8px;"
                                    data-massic-copy-target="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>"
                                >
                                    <?php esc_html_e('Copy', 'massic-integration'); ?>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>"><?php esc_html_e('Client Secret', 'massic-integration'); ?></label></th>
                            <td>
                                <input
                                    id="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>"
                                    name="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>"
                                    type="password"
                                    class="regular-text"
                                    value="<?php echo esc_attr(Massic_Options::get_client_secret()); ?>"
                                    autocomplete="new-password"
                                />
                                <button
                                    type="button"
                                    class="button button-secondary massic-copy-button"
                                    style="margin-left:8px;"
                                    data-massic-copy-target="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>"
                                >
                                    <?php esc_html_e('Copy', 'massic-integration'); ?>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_NONCE_TTL); ?>"><?php esc_html_e('Nonce TTL (seconds)', 'massic-integration'); ?></label></th>
                            <td><input name="<?php echo esc_attr(Massic_Options::OPTION_NONCE_TTL); ?>" type="number" min="60" max="3600" class="small-text" value="<?php echo esc_attr(Massic_Options::get_nonce_ttl()); ?>" /></td>
                        </tr>
                    </table>
                    <?php submit_button(__('Save Manual Settings', 'massic-integration')); ?>
                </form>
            </details>
        </div>
        <?php
    }

    private function format_datetime_for_admin($value) {
        $raw = trim((string) $value);
        if (!$raw) {
            return '';
        }

        $timestamp = strtotime($raw);
        if (!$timestamp) {
            return $raw;
        }

        $absolute = wp_date('M j, Y g:i A T', $timestamp);
        $now = time();
        $distance = human_time_diff($timestamp, $now);
        $relative = $timestamp <= $now ? ($distance . ' ago') : ('in ' . $distance);

        return $absolute . ' (' . $relative . ')';
    }

    private function redirect_with_notice($message, $type = 'success') {
        $redirect_url = add_query_arg(array(
            'page' => self::PAGE_SLUG,
            'massic_notice' => (string) $message,
            'massic_notice_type' => $type === 'error' ? 'error' : 'success',
            '_massic_notice_nonce' => wp_create_nonce('massic_admin_notice'),
        ), admin_url('options-general.php'));

        wp_safe_redirect($redirect_url);
        exit;
    }
}
