<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Content {
    const META_HEAD_PAYLOAD = '_massic_head_payload';
    const META_SEO_TITLE = '_massic_meta_title';
    const META_SEO_DESCRIPTION = '_massic_meta_description';
    const META_FEATURED_IMAGE_ASSET_ID = '_massic_featured_image_asset_id';
    const META_FEATURED_IMAGE_CDN_URL = '_massic_featured_image_cdn_url';
    const META_FEATURED_IMAGE_ATTACHMENT_ID = '_massic_featured_image_attachment_id';
    const META_FEATURED_IMAGE_WP_URL = '_massic_featured_image_wp_url';
    const META_FEATURED_IMAGE_ALT_TEXT = '_massic_featured_image_alt_text';
    const META_FEATURED_IMAGE_WIDTH = '_massic_featured_image_width';
    const META_FEATURED_IMAGE_HEIGHT = '_massic_featured_image_height';
    const META_FEATURED_IMAGE_MIME_TYPE = '_massic_featured_image_mime_type';
    const REQUIRED_PAGE_TEMPLATE_NAME = 'Massic Template';

    private function get_available_page_templates() {
        $templates = array();
        $theme = wp_get_theme();

        if ($theme && method_exists($theme, 'get_page_templates')) {
            $raw_templates = $theme->get_page_templates(null, 'page');
        } elseif (function_exists('get_page_templates')) {
            $raw_templates = get_page_templates(null, 'page');
        } else {
            $raw_templates = array();
        }

        if (!is_array($raw_templates)) {
            return $templates;
        }

        foreach ($raw_templates as $template_file => $template_name) {
            $file = sanitize_text_field((string) $template_file);
            $name = sanitize_text_field((string) $template_name);
            if ($file === '' || $name === '') {
                continue;
            }

            $templates[$file] = $name;
        }

        return $templates;
    }

    private function find_required_page_template() {
        $templates = $this->get_available_page_templates();

        foreach ($templates as $template_file => $template_name) {
            if (trim((string) $template_name) === self::REQUIRED_PAGE_TEMPLATE_NAME) {
                return array(
                    'name' => $template_name,
                    'file' => $template_file,
                );
            }
        }

        return null;
    }

    public function get_required_page_template_status() {
        $theme = wp_get_theme();
        $matched_template = $this->find_required_page_template();

        return array(
            'ok' => true,
            'templateName' => self::REQUIRED_PAGE_TEMPLATE_NAME,
            'exists' => is_array($matched_template),
            'templateFile' => is_array($matched_template) ? $matched_template['file'] : null,
            'theme' => array(
                'name' => sanitize_text_field((string) $theme->get('Name')),
                'stylesheet' => sanitize_text_field((string) $theme->get_stylesheet()),
                'template' => sanitize_text_field((string) $theme->get_template()),
            ),
        );
    }

    private function missing_required_page_template_error() {
        return new WP_Error(
            'missing_wordpress_massic_template',
            'Massic Template doesn\'t exist in this WordPress theme. Add a page template named "Massic Template" before publishing pages.',
            array(
                'status' => 409,
                'templateName' => self::REQUIRED_PAGE_TEMPLATE_NAME,
                'exists' => false,
            )
        );
    }

    private function sanitize_status($status) {
        $allowed = array('draft', 'pending', 'publish', 'private', 'future');
        $value = sanitize_text_field((string) $status);
        if (!$value) {
            return 'draft';
        }

        if (!in_array($value, $allowed, true)) {
            return 'draft';
        }

        return $value;
    }

    private function sanitize_head($head) {
        if (!is_array($head)) {
            return array();
        }

        $sanitized = $head;
        $text_fields = array(
            'title',
            'seoTitle',
            'metaDescription',
            'metaKeywords',
            'ogTitle',
            'ogDescription',
            'ogImage',
            'twitterCard',
            'twitterTitle',
            'twitterDescription',
            'canonicalUrl',
            'robots',
        );

        foreach ($text_fields as $field) {
            if (!isset($sanitized[$field]) || !is_scalar($sanitized[$field])) {
                continue;
            }
            $sanitized[$field] = sanitize_text_field((string) $sanitized[$field]);
        }

        if (isset($sanitized['meta']) && is_array($sanitized['meta'])) {
            $meta = $sanitized['meta'];
            foreach (array('description', 'keywords') as $field) {
                if (!isset($meta[$field]) || !is_scalar($meta[$field])) {
                    continue;
                }
                $meta[$field] = sanitize_text_field((string) $meta[$field]);
            }
            $sanitized['meta'] = $meta;
        }

        if (isset($sanitized['metaKeys']) && is_array($sanitized['metaKeys'])) {
            $meta_keys = array();
            foreach ($sanitized['metaKeys'] as $key => $value) {
                $meta_key = sanitize_key((string) $key);
                if (!$this->is_allowed_custom_meta_key($meta_key)) {
                    continue;
                }
                if ($value === null) {
                    $meta_keys[$meta_key] = '';
                    continue;
                }
                if (!is_scalar($value)) {
                    continue;
                }
                $meta_keys[$meta_key] = sanitize_text_field((string) $value);
            }
            $sanitized['metaKeys'] = $meta_keys;
        }

        return $sanitized;
    }

    private function is_allowed_custom_meta_key($meta_key) {
        return is_string($meta_key) && preg_match('/^_massic_[a-z0-9_]+$/', $meta_key) === 1;
    }

    private function sanitize_featured_image($featured_image) {
        if ($featured_image === null) {
            return null;
        }

        if (!is_array($featured_image)) {
            return new WP_Error('massic_invalid_featured_image', 'featuredImage must be an object or null', array('status' => 400));
        }

        $asset_id = isset($featured_image['assetId']) ? sanitize_text_field((string) $featured_image['assetId']) : '';
        $cdn_url = isset($featured_image['cdnUrl']) ? esc_url_raw((string) $featured_image['cdnUrl']) : '';
        $alt_text = isset($featured_image['altText']) ? sanitize_text_field((string) $featured_image['altText']) : '';
        $mime_type = isset($featured_image['mimeType']) ? sanitize_text_field((string) $featured_image['mimeType']) : '';
        $width = isset($featured_image['width']) ? absint($featured_image['width']) : 0;
        $height = isset($featured_image['height']) ? absint($featured_image['height']) : 0;

        if (!$asset_id || !$cdn_url || !wp_http_validate_url($cdn_url)) {
            return new WP_Error('massic_invalid_featured_image', 'featuredImage assetId and cdnUrl are required', array('status' => 400));
        }

        return array(
            'assetId' => $asset_id,
            'cdnUrl' => $cdn_url,
            'altText' => $alt_text,
            'mimeType' => $mime_type,
            'width' => $width > 0 ? $width : null,
            'height' => $height > 0 ? $height : null,
        );
    }

    private function clear_featured_image_assignment($post_id) {
        if (function_exists('delete_post_thumbnail')) {
            delete_post_thumbnail($post_id);
        } else {
            delete_post_meta($post_id, '_thumbnail_id');
        }

        delete_post_meta($post_id, self::META_FEATURED_IMAGE_ASSET_ID);
        delete_post_meta($post_id, self::META_FEATURED_IMAGE_CDN_URL);
        delete_post_meta($post_id, self::META_FEATURED_IMAGE_ATTACHMENT_ID);
        delete_post_meta($post_id, self::META_FEATURED_IMAGE_WP_URL);
        delete_post_meta($post_id, self::META_FEATURED_IMAGE_ALT_TEXT);
        delete_post_meta($post_id, self::META_FEATURED_IMAGE_WIDTH);
        delete_post_meta($post_id, self::META_FEATURED_IMAGE_HEIGHT);
        delete_post_meta($post_id, self::META_FEATURED_IMAGE_MIME_TYPE);
    }

    private function persist_featured_image_attachment_meta($post_id, $asset_id, $attachment_id, $alt_text) {
        $attachment_id = absint($attachment_id);
        if ($post_id <= 0 || $attachment_id <= 0) {
            return;
        }

        if ($alt_text !== '') {
            update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt_text);
        }

        $image_src = wp_get_attachment_image_src($attachment_id, 'full');
        $attachment_url = wp_get_attachment_url($attachment_id);
        $image_url = '';
        $width = 0;
        $height = 0;

        if (is_array($image_src)) {
            $image_url = !empty($image_src[0]) ? esc_url_raw((string) $image_src[0]) : '';
            $width = !empty($image_src[1]) ? absint($image_src[1]) : 0;
            $height = !empty($image_src[2]) ? absint($image_src[2]) : 0;
        }

        if (!$image_url && $attachment_url) {
            $image_url = esc_url_raw((string) $attachment_url);
        }

        $attachment_alt = sanitize_text_field((string) get_post_meta($attachment_id, '_wp_attachment_image_alt', true));
        if ($attachment_alt === '' && $alt_text !== '') {
            $attachment_alt = $alt_text;
        }

        $mime_type = sanitize_text_field((string) get_post_mime_type($attachment_id));

        update_post_meta($post_id, self::META_FEATURED_IMAGE_ASSET_ID, $asset_id);
        update_post_meta($post_id, self::META_FEATURED_IMAGE_ATTACHMENT_ID, (int) $attachment_id);
        delete_post_meta($post_id, self::META_FEATURED_IMAGE_CDN_URL);

        if ($image_url) {
            update_post_meta($post_id, self::META_FEATURED_IMAGE_WP_URL, $image_url);
        } else {
            delete_post_meta($post_id, self::META_FEATURED_IMAGE_WP_URL);
        }

        if ($attachment_alt !== '') {
            update_post_meta($post_id, self::META_FEATURED_IMAGE_ALT_TEXT, $attachment_alt);
        } else {
            delete_post_meta($post_id, self::META_FEATURED_IMAGE_ALT_TEXT);
        }

        if ($width > 0) {
            update_post_meta($post_id, self::META_FEATURED_IMAGE_WIDTH, $width);
        } else {
            delete_post_meta($post_id, self::META_FEATURED_IMAGE_WIDTH);
        }

        if ($height > 0) {
            update_post_meta($post_id, self::META_FEATURED_IMAGE_HEIGHT, $height);
        } else {
            delete_post_meta($post_id, self::META_FEATURED_IMAGE_HEIGHT);
        }

        if ($mime_type !== '') {
            update_post_meta($post_id, self::META_FEATURED_IMAGE_MIME_TYPE, $mime_type);
        } else {
            delete_post_meta($post_id, self::META_FEATURED_IMAGE_MIME_TYPE);
        }
    }

    private function sync_featured_image_to_post($post_id, $type, $featured_image) {
        if ($featured_image === null) {
            $this->clear_featured_image_assignment($post_id);
            return true;
        }

        if (!is_array($featured_image)) {
            return new WP_Error('massic_invalid_featured_image', 'featuredImage must be an object or null', array('status' => 400));
        }

        $post_type = get_post_type($post_id);
        if (!$post_type) {
            return new WP_Error('massic_featured_image_unsupported', 'This WordPress content type does not support featured images', array('status' => 400));
        }
        $supports_thumbnail = post_type_supports($post_type, 'thumbnail');

        $asset_id = isset($featured_image['assetId']) ? sanitize_text_field((string) $featured_image['assetId']) : '';
        $cdn_url = isset($featured_image['cdnUrl']) ? esc_url_raw((string) $featured_image['cdnUrl']) : '';
        $alt_text = isset($featured_image['altText']) ? sanitize_text_field((string) $featured_image['altText']) : '';

        if (!$asset_id || !$cdn_url || !wp_http_validate_url($cdn_url)) {
            return new WP_Error('massic_invalid_featured_image', 'featuredImage assetId and cdnUrl are required', array('status' => 400));
        }

        $existing_asset_id = sanitize_text_field((string) get_post_meta($post_id, self::META_FEATURED_IMAGE_ASSET_ID, true));
        $existing_attachment_id = absint(get_post_meta($post_id, self::META_FEATURED_IMAGE_ATTACHMENT_ID, true));

        if (
            $existing_asset_id &&
            $existing_asset_id === $asset_id &&
            $existing_attachment_id > 0 &&
            get_post($existing_attachment_id)
        ) {
            if (!$supports_thumbnail) {
                $this->persist_featured_image_attachment_meta($post_id, $asset_id, $existing_attachment_id, $alt_text);
                return true;
            }

            if (set_post_thumbnail($post_id, $existing_attachment_id)) {
                $this->persist_featured_image_attachment_meta($post_id, $asset_id, $existing_attachment_id, $alt_text);
                return true;
            }

            delete_post_meta($post_id, self::META_FEATURED_IMAGE_ATTACHMENT_ID);
            delete_post_meta($post_id, '_thumbnail_id');
        }

        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $temp_file = download_url($cdn_url, 30);
        if (is_wp_error($temp_file)) {
            return new WP_Error('massic_featured_image_failed', 'Failed to download featured image from Massic CDN', array(
                'status' => 500,
                'details' => $temp_file->get_error_message(),
            ));
        }

        $parsed_url = wp_parse_url($cdn_url);
        $file_name = isset($parsed_url['path']) ? basename($parsed_url['path']) : 'featured-image';
        if (!$file_name) {
            $file_name = 'featured-image';
        }

        $file_array = array(
            'name' => sanitize_file_name($file_name),
            'tmp_name' => $temp_file,
        );

        $attachment_id = media_handle_sideload($file_array, $post_id);
        if (is_wp_error($attachment_id)) {
            wp_delete_file($temp_file);
            return new WP_Error('massic_featured_image_failed', 'Failed to import featured image into WordPress media library', array(
                'status' => 500,
                'details' => $attachment_id->get_error_message(),
            ));
        }

        if ($supports_thumbnail && !set_post_thumbnail($post_id, $attachment_id)) {
            return new WP_Error('massic_featured_image_failed', 'Failed to assign featured image to WordPress content', array('status' => 500));
        }

        $this->persist_featured_image_attachment_meta($post_id, $asset_id, $attachment_id, $alt_text);

        return true;
    }

    private function persist_head_meta_keys($post_id, $type, $head) {
        if ($type !== 'post' || $post_id <= 0 || !is_array($head)) {
            return;
        }

        $meta_values = array(
            self::META_SEO_TITLE => '',
            self::META_SEO_DESCRIPTION => '',
        );

        if (!empty($head['seoTitle']) && is_scalar($head['seoTitle'])) {
            $meta_values[self::META_SEO_TITLE] = sanitize_text_field((string) $head['seoTitle']);
        }

        if (!empty($head['metaDescription']) && is_scalar($head['metaDescription'])) {
            $meta_values[self::META_SEO_DESCRIPTION] = sanitize_textarea_field((string) $head['metaDescription']);
        }

        if (!empty($head['metaKeys']) && is_array($head['metaKeys'])) {
            foreach ($head['metaKeys'] as $meta_key => $value) {
                $next_key = sanitize_key((string) $meta_key);
                if (!$this->is_allowed_custom_meta_key($next_key)) {
                    continue;
                }
                if ($value === null) {
                    $meta_values[$next_key] = '';
                    continue;
                }
                if (!is_scalar($value)) {
                    continue;
                }
                $meta_values[$next_key] = sanitize_text_field((string) $value);
            }
        }

        foreach ($meta_values as $meta_key => $value) {
            if ($value === '') {
                delete_post_meta($post_id, $meta_key);
                continue;
            }
            update_post_meta($post_id, $meta_key, $value);
        }
    }

    private function contains_massic_markup($html) {
        if (!is_string($html) || $html === '') {
            return false;
        }

        if (stripos($html, 'massic-content') !== false) {
            return true;
        }

        return preg_match('/class\s*=\s*["\'][^"\']*massic-[^"\']*["\']/i', $html) === 1;
    }

    /**
     * Allowed HTML for Massic post/page content. Extends post context with iframe
     * so that YouTube and other oEmbeds inside .massic-video-wrap are preserved.
     * wp_kses_post() strips iframes by default.
     *
     * @return array<string, array<string, bool>> Map of tag name to allowed attributes.
     */
    private function get_allowed_html_for_massic_content() {
        $allowed = wp_kses_allowed_html('post');
        $allowed['iframe'] = array(
            'src'             => true,
            'title'           => true,
            'width'           => true,
            'height'          => true,
            'frameborder'     => true,
            'allow'           => true,
            'allowfullscreen' => true,
            'loading'         => true,
        );
        return $allowed;
    }

    private function strip_style_tags($html) {
        if (!is_string($html) || $html === '') {
            return '';
        }

        $next = preg_replace('/<style\b[^>]*>.*?<\/style>/is', '', $html);
        if (!is_string($next)) {
            return $html;
        }

        return trim($next);
    }

    private function strip_stale_massic_inline_css_text($html) {
        if (!is_string($html) || $html === '') {
            return '';
        }

        $next = preg_replace(
            '/\/\*\s*MASSIC_INLINE_CSS_START\s*\*\/[\s\S]*?\/\*\s*MASSIC_INLINE_CSS_END\s*\*\//i',
            '',
            $html
        );

        if (!is_string($next)) {
            return $html;
        }

        return trim($next);
    }

    private function strip_legacy_broken_massic_css_text($html) {
        if (!is_string($html) || $html === '') {
            return '';
        }

        $legacy_marker = 'Neutral defaults only: common on US local-business WordPress themes.';
        if (strpos($html, $legacy_marker) === false) {
            return $html;
        }

        $start = strpos($html, '.massic-content {');
        if ($start === false) {
            return $html;
        }

        $next_tag = strpos($html, '<', $start + 1);
        if ($next_tag === false) {
            return trim(substr($html, 0, $start));
        }

        $prefix = substr($html, 0, $start);
        $suffix = substr($html, $next_tag);

        return trim($prefix . "\n" . $suffix);
    }

    private function build_published_content_html($content_html, $massic_css_overrides, $type = 'page') {
        $clean_html = $this->strip_style_tags($content_html);
        if (!$this->contains_massic_markup($clean_html)) {
            return $clean_html;
        }

        return $clean_html;
    }

    private function run_with_wp_kses_filters_disabled($callback) {
        /*
         * Content is already sanitized with get_allowed_html_for_massic_content().
         * WordPress' save filters would strip the allowed iframe embeds afterward,
         * so temporarily remove them only for this controlled insert/update.
         */
        $filters = array(
            'content_save_pre',
            'excerpt_save_pre',
            'content_filtered_save_pre',
        );

        $removed = array();
        foreach ($filters as $filter_name) {
            $has_filter = has_filter($filter_name, 'wp_filter_post_kses');
            $removed[$filter_name] = ($has_filter !== false) ? (int) $has_filter : false;
            if ($removed[$filter_name] !== false) {
                remove_filter($filter_name, 'wp_filter_post_kses');
            }
        }

        try {
            return call_user_func($callback);
        } finally {
            foreach ($filters as $filter_name) {
                if ($removed[$filter_name] !== false) {
                    add_filter($filter_name, 'wp_filter_post_kses', (int) $removed[$filter_name], 1);
                }
            }
        }
    }

    private function normalize_slug_path($value) {
        if (!is_string($value)) {
            return '';
        }

        $raw = trim((string) $value);
        if ($raw === '') {
            return '';
        }

        $raw = str_replace('\\', '/', $raw);

        if (preg_match('/^[a-z][a-z0-9+.\-]*:\/\//i', $raw)) {
            $parsed_path = wp_parse_url($raw, PHP_URL_PATH);
            if (is_string($parsed_path)) {
                $raw = $parsed_path;
            }
        } elseif (strpos($raw, '//') === 0) {
            $parsed_path = wp_parse_url('https:' . $raw, PHP_URL_PATH);
            if (is_string($parsed_path)) {
                $raw = $parsed_path;
            }
        } elseif (preg_match('/^[a-z0-9.\-]+\.[a-z]{2,}(?::\d+)?\//i', $raw)) {
            $parsed_path = wp_parse_url('https://' . $raw, PHP_URL_PATH);
            if (is_string($parsed_path)) {
                $raw = $parsed_path;
            }
        }

        $raw = preg_replace('/[#?].*$/', '', $raw);
        if (!is_string($raw)) {
            $raw = trim((string) $value);
        }
        $raw = trim($raw, '/');

        $segments = explode('/', $raw);
        $normalized = array();
        foreach ($segments as $segment) {
            $clean = sanitize_title((string) $segment);
            if ($clean !== '') {
                $normalized[] = $clean;
            }
        }

        if (empty($normalized)) {
            return '';
        }

        return implode('/', $normalized);
    }

    private function normalize_slug_for_type($type, $value) {
        $normalized = $this->normalize_slug_path($value);
        if ($normalized === '') {
            return '';
        }

        if ($type !== 'post') {
            return $normalized;
        }

        $segments = $this->split_slug_segments($normalized);
        if (count($segments) > 1 && in_array($segments[0], array('blog', 'blogs'), true)) {
            array_shift($segments);
        }

        if (count($segments) !== 1) {
            return '';
        }

        $leaf = sanitize_title((string) $segments[0]);
        return is_string($leaf) ? $leaf : '';
    }

    private function split_slug_segments($slug_path) {
        $normalized = $this->normalize_slug_path($slug_path);
        if ($normalized === '') {
            return array();
        }

        $parts = explode('/', $normalized);
        $segments = array();
        foreach ($parts as $part) {
            if (is_string($part) && $part !== '') {
                $segments[] = $part;
            }
        }

        return $segments;
    }

    private function get_slug_leaf($slug_path) {
        $segments = $this->split_slug_segments($slug_path);
        if (empty($segments)) {
            return '';
        }

        $leaf = end($segments);
        return is_string($leaf) ? $leaf : '';
    }

    private function build_suggested_slug($slug_path, $index) {
        $normalized = $this->normalize_slug_path($slug_path);
        if ($normalized === '') {
            return '';
        }

        $suffix_index = absint($index);
        if ($suffix_index < 2) {
            $suffix_index = 2;
        }

        $parts = explode('/', $normalized);
        $leaf = array_pop($parts);
        if (!is_string($leaf) || $leaf === '') {
            return '';
        }

        $base_leaf = preg_replace('/-\d+$/', '', $leaf);
        if (!is_string($base_leaf) || $base_leaf === '') {
            $base_leaf = $leaf;
        }

        $suggested_leaf = $base_leaf . '-' . $suffix_index;
        if (empty($parts)) {
            return $suggested_leaf;
        }

        return implode('/', $parts) . '/' . $suggested_leaf;
    }

    private function suggest_available_slug($type, $slug_path, $exclude_wp_id = 0) {
        $normalized = $this->normalize_slug_path($slug_path);
        if ($normalized === '') {
            return null;
        }

        // If parent path cannot host child pages, suffixing the leaf will not fix the conflict.
        if ($type === 'page' && $this->find_page_parent_type_conflict_post($normalized, $exclude_wp_id)) {
            return null;
        }

        if (!$this->find_slug_conflict($type, $normalized, $exclude_wp_id)) {
            return $normalized;
        }

        for ($i = 2; $i <= 200; $i++) {
            $candidate = $this->build_suggested_slug($normalized, $i);
            if ($candidate === '') {
                continue;
            }

            if (!$this->find_slug_conflict($type, $candidate, $exclude_wp_id)) {
                return $candidate;
            }
        }

        return null;
    }

    private function persist_full_slug_as_post_name($post_id, $slug_path) {
        $post_id = absint($post_id);
        if ($post_id <= 0) {
            return;
        }

        $normalized = $this->normalize_slug_path($slug_path);
        if ($normalized === '') {
            return;
        }

        global $wpdb;
        if (!isset($wpdb->posts)) {
            return;
        }

        // WordPress core strips "/" from post_name; persist full route path explicitly.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Required to preserve slash-based Massic routes in post_name.
        $wpdb->update(
            $wpdb->posts,
            array(
                'post_name' => $normalized,
            ),
            array(
                'ID' => $post_id,
            ),
            array('%s'),
            array('%d')
        );

        clean_post_cache($post_id);
    }

    private function get_post_slug_path($post) {
        if (!$post || !isset($post->ID)) {
            return '';
        }

        $post_id = (int) $post->ID;
        $post_type = get_post_type($post_id);
        if ($post_type === 'page') {
            $page_uri = get_page_uri($post_id);
            $normalized_page_uri = $this->normalize_slug_path((string) $page_uri);
            if ($normalized_page_uri !== '') {
                return $normalized_page_uri;
            }
        }

        return $this->normalize_slug_path((string) $post->post_name);
    }

    private function resolve_post_from_url_path($slug_path) {
        $normalized = $this->normalize_slug_path($slug_path);
        if ($normalized === '') {
            return null;
        }

        $base = rtrim(home_url('/'), '/');
        if ($base === '') {
            return null;
        }

        $candidates = array(
            $base . '/' . $normalized,
            $base . '/' . $normalized . '/',
        );

        foreach ($candidates as $url) {
            $post_id = url_to_postid($url);
            if ($post_id <= 0) {
                continue;
            }

            $post = get_post($post_id);
            if ($post && in_array($post->post_type, array('post', 'page'), true)) {
                return $post;
            }
        }

        return null;
    }

    private function is_non_trash_supported_post($post, $exclude_wp_id = 0) {
        if (!$post || !isset($post->ID)) {
            return false;
        }

        $post_id = (int) $post->ID;
        if ($post_id <= 0) {
            return false;
        }

        if (absint($exclude_wp_id) > 0 && $post_id === absint($exclude_wp_id)) {
            return false;
        }

        if (!in_array($post->post_type, array('post', 'page'), true)) {
            return false;
        }

        return get_post_status($post_id) !== 'trash';
    }

    private function find_non_trash_supported_post_by_post_name($post_name, $post_type_scope = 'all', $exclude_wp_id = 0) {
        $normalized_name = $this->normalize_slug_path($post_name);
        if ($normalized_name === '') {
            return null;
        }

        $scope = ($post_type_scope === 'post') ? 'post' : 'all';
        $cache_group = 'massic_wp_connector';
        $cache_key = 'post_name_' . md5($scope . '|' . $normalized_name);
        $post_ids = wp_cache_get($cache_key, $cache_group);

        if (false === $post_ids) {
            global $wpdb;
            if (!isset($wpdb->posts)) {
                return null;
            }

            if ($scope === 'post') {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Exact slash-preserving post_name lookup is cached and required for Massic route compatibility.
                $post_ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts}
                     WHERE post_name = %s
                       AND post_type = 'post'
                       AND post_status <> 'trash'
                     ORDER BY ID ASC
                     LIMIT 10",
                    $normalized_name
                ));
            } else {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Exact slash-preserving post_name lookup is cached and required for Massic route compatibility.
                $post_ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts}
                     WHERE post_name = %s
                       AND post_type IN ('post', 'page')
                       AND post_status <> 'trash'
                     ORDER BY ID ASC
                     LIMIT 10",
                    $normalized_name
                ));
            }

            wp_cache_set($cache_key, $post_ids, $cache_group, 5 * MINUTE_IN_SECONDS);
        }

        if (!is_array($post_ids) || empty($post_ids)) {
            return null;
        }

        foreach ($post_ids as $post_id_raw) {
            $post_id = absint($post_id_raw);
            if ($post_id <= 0) {
                continue;
            }

            $post = get_post($post_id);
            if ($this->is_non_trash_supported_post($post, $exclude_wp_id)) {
                return $post;
            }
        }

        return null;
    }

    private function get_non_trash_page_by_path($slug_path) {
        $normalized = $this->normalize_slug_path($slug_path);
        if ($normalized === '') {
            return null;
        }

        $page = get_page_by_path($normalized, OBJECT, 'page');
        if (!$page || !isset($page->ID)) {
            return null;
        }

        if (get_post_status((int) $page->ID) === 'trash') {
            return null;
        }

        return $page;
    }

    private function find_page_child_by_slug($parent_id, $slug, $exclude_wp_id = 0) {
        $normalized_slug = sanitize_title((string) $slug);
        if ($normalized_slug === '') {
            return null;
        }

        $parent_id = absint($parent_id);
        $exclude_id = absint($exclude_wp_id);

        $matches = get_posts(array(
            'post_type' => 'page',
            'post_parent' => $parent_id,
            'name' => $normalized_slug,
            'post_status' => array('publish', 'draft', 'pending', 'private', 'future'),
            'numberposts' => 10,
            'orderby' => 'ID',
            'order' => 'ASC',
            'suppress_filters' => false,
        ));

        if (!is_array($matches) || empty($matches)) {
            return null;
        }

        foreach ($matches as $post) {
            if (!$post || !isset($post->ID)) {
                continue;
            }

            $post_id = (int) $post->ID;
            if ($exclude_id > 0 && $post_id === $exclude_id) {
                continue;
            }

            if (get_post_status($post_id) === 'trash') {
                continue;
            }

            return $post;
        }

        return null;
    }

    private function build_parent_title_from_slug($slug_segment) {
        $readable = str_replace(array('-', '_'), ' ', (string) $slug_segment);
        $collapsed = preg_replace('/\s+/', ' ', $readable);
        if (!is_string($collapsed)) {
            $collapsed = $readable;
        }
        $readable = trim($collapsed);
        if ($readable === '') {
            return 'Untitled';
        }

        return ucwords($readable);
    }

    private function find_or_create_page_parent($parent_id, $slug_segment, $status) {
        $normalized_slug = sanitize_title((string) $slug_segment);
        if ($normalized_slug === '') {
            return new WP_Error('massic_invalid_slug', 'Invalid parent slug segment', array('status' => 400));
        }

        $existing = $this->find_page_child_by_slug($parent_id, $normalized_slug);
        if ($existing) {
            return $existing;
        }

        $inserted = wp_insert_post(array(
            'post_type' => 'page',
            'post_parent' => absint($parent_id),
            'post_name' => $normalized_slug,
            'post_title' => $this->build_parent_title_from_slug($normalized_slug),
            'post_status' => $this->sanitize_status($status),
        ), true);

        if (is_wp_error($inserted)) {
            return new WP_Error('massic_parent_create_failed', $inserted->get_error_message(), array('status' => 500));
        }

        $post = get_post($inserted);
        if (!$post || !isset($post->ID)) {
            return new WP_Error('massic_parent_create_failed', 'Failed to create parent page', array('status' => 500));
        }

        return $post;
    }

    private function find_page_parent_type_conflict_post($slug_path, $exclude_wp_id = 0) {
        $segments = $this->split_slug_segments($slug_path);
        if (count($segments) <= 1) {
            return null;
        }

        $prefix_segments = array();
        for ($i = 0; $i < count($segments) - 1; $i++) {
            $prefix_segments[] = $segments[$i];
            $prefix_path = implode('/', $prefix_segments);

            $non_page_exact_match = $this->find_non_trash_supported_post_by_post_name($prefix_path, 'post', $exclude_wp_id);
            if ($non_page_exact_match) {
                return $non_page_exact_match;
            }

            $resolved_post = $this->resolve_post_from_url_path($prefix_path);
            if (!$this->is_non_trash_supported_post($resolved_post, $exclude_wp_id)) {
                continue;
            }

            if ($resolved_post->post_type !== 'page') {
                return $resolved_post;
            }
        }

        return null;
    }

    private function find_slug_conflict($type, $slug_path, $exclude_wp_id = 0) {
        $normalized = $this->normalize_slug_path($slug_path);
        if ($normalized === '') {
            return null;
        }

        $exclude_id = absint($exclude_wp_id);

        if ($type === 'page') {
            $page_by_path = $this->get_non_trash_page_by_path($normalized);
            if ($this->is_non_trash_supported_post($page_by_path, $exclude_id)) {
                return array(
                    'post' => $page_by_path,
                    'reason' => 'slug_exists',
                );
            }

            $exact_slug_match = $this->find_non_trash_supported_post_by_post_name($normalized, 'all', $exclude_id);
            if ($this->is_non_trash_supported_post($exact_slug_match, $exclude_id)) {
                return array(
                    'post' => $exact_slug_match,
                    'reason' => ($exact_slug_match->post_type !== 'page') ? 'type_mismatch' : 'slug_exists',
                );
            }

            $resolved_full_path = $this->resolve_post_from_url_path($normalized);
            if ($this->is_non_trash_supported_post($resolved_full_path, $exclude_id) && $resolved_full_path->post_type !== 'page') {
                return array(
                    'post' => $resolved_full_path,
                    'reason' => 'type_mismatch',
                );
            }

            $parent_type_conflict = $this->find_page_parent_type_conflict_post($normalized, $exclude_id);
            if ($this->is_non_trash_supported_post($parent_type_conflict, $exclude_id)) {
                return array(
                    'post' => $parent_type_conflict,
                    'reason' => 'parent_type_conflict',
                );
            }

            return null;
        }

        $exact_slug_match = $this->find_non_trash_supported_post_by_post_name($normalized, 'all', $exclude_id);
        if ($this->is_non_trash_supported_post($exact_slug_match, $exclude_id)) {
            return array(
                'post' => $exact_slug_match,
                'reason' => ($exact_slug_match->post_type !== $type) ? 'type_mismatch' : 'slug_exists',
            );
        }

        $resolved_post = $this->resolve_post_from_url_path($normalized);
        if ($this->is_non_trash_supported_post($resolved_post, $exclude_id)) {
            return array(
                'post' => $resolved_post,
                'reason' => ($resolved_post->post_type !== $type) ? 'type_mismatch' : 'slug_exists',
            );
        }

        return null;
    }

    private function apply_slug_to_post_arr($type, $slug_path, &$post_arr, $wp_id = 0) {
        $normalized = $this->normalize_slug_path($slug_path);
        if ($normalized === '') {
            return null;
        }

        if ($type === 'post') {
            $post_arr['post_parent'] = 0;
            $post_arr['post_name'] = $normalized;
            return null;
        }

        if ($type !== 'page') {
            return null;
        }

        $segments = $this->split_slug_segments($normalized);
        if (empty($segments)) {
            return new WP_Error('massic_invalid_slug', 'Invalid slug path', array('status' => 400));
        }

        $leaf_slug = $this->get_slug_leaf($normalized);
        if ($leaf_slug === '') {
            return new WP_Error('massic_invalid_slug', 'Invalid slug path', array('status' => 400));
        }

        $parent_id = 0;
        $existing_page = $this->get_non_trash_page_by_path($normalized);
        if ($existing_page) {
            $existing_id = (int) $existing_page->ID;
            if ($existing_id > 0 && $existing_id !== absint($wp_id)) {
                $conflict_summary = $this->build_post_summary($existing_page);
                return new WP_Error('slug_conflict', 'Slug already exists', array(
                    'status' => 409,
                    'slug' => $normalized,
                    'typeMismatch' => false,
                    'suggestedSlug' => $this->suggest_available_slug($type, $normalized, $wp_id),
                    'conflict' => $conflict_summary,
                    'reason' => 'slug_exists',
                ));
            }

            $parent_id = absint($existing_page->post_parent);
        } elseif (count($segments) > 1) {
            $parent_type_conflict = $this->find_page_parent_type_conflict_post($normalized, $wp_id);
            if ($parent_type_conflict) {
                $conflict_summary = $this->build_post_summary($parent_type_conflict);
                return new WP_Error('slug_conflict', 'Nested page path is blocked because a parent segment is not a page', array(
                    'status' => 409,
                    'slug' => $normalized,
                    'typeMismatch' => true,
                    'suggestedSlug' => null,
                    'conflict' => $conflict_summary,
                    'reason' => 'parent_type_conflict',
                ));
            }

            $parent_segments = array_slice($segments, 0, count($segments) - 1);
            $target_status = isset($post_arr['post_status']) ? (string) $post_arr['post_status'] : 'draft';
            foreach ($parent_segments as $segment) {
                $parent_page = $this->find_or_create_page_parent($parent_id, $segment, $target_status);
                if (is_wp_error($parent_page)) {
                    return $parent_page;
                }

                $parent_id = (int) $parent_page->ID;
            }
        }

        $post_arr['post_parent'] = $parent_id;
        $post_arr['post_name'] = $leaf_slug;
        return null;
    }

    private function build_post_summary($post) {
        if (!$post || !isset($post->ID)) {
            return null;
        }

        $post_id = (int) $post->ID;
        $slug_path = $this->get_post_slug_path($post);
        return array(
            'wpId' => $post_id,
            'title' => get_the_title($post_id),
            'status' => get_post_status($post_id),
            'wpType' => get_post_type($post_id),
            'slug' => $slug_path !== '' ? $slug_path : (string) $post->post_name,
            'permalink' => get_permalink($post_id),
            'editUrl' => admin_url('post.php?post=' . $post_id . '&action=edit'),
        );
    }

    public function slug_check($payload) {
        $type = isset($payload['type']) ? sanitize_text_field((string) $payload['type']) : '';
        if (!in_array($type, array('post', 'page'), true)) {
            return new WP_Error('massic_invalid_type', 'Invalid content type', array('status' => 400));
        }

        $raw_slug = isset($payload['slug']) ? trim((string) $payload['slug']) : '';
        $slug = isset($payload['slug']) ? $this->normalize_slug_for_type($type, (string) $payload['slug']) : '';
        if ($raw_slug !== '' && $slug === '') {
            $invalid_message = ($type === 'post')
                ? 'Blog slug must be a single segment and cannot include nested "/" paths'
                : 'Slug must contain at least one valid segment and cannot be root "/"';
            return new WP_Error('massic_invalid_slug', $invalid_message, array('status' => 400));
        }
        if (!$slug) {
            return new WP_Error('massic_missing_slug', 'slug is required', array('status' => 400));
        }

        $exclude_wp_id = isset($payload['excludeWpId']) ? absint($payload['excludeWpId']) : 0;
        $conflict_state = $this->find_slug_conflict($type, $slug, $exclude_wp_id);
        $conflict_post = is_array($conflict_state) && isset($conflict_state['post']) ? $conflict_state['post'] : null;
        $conflict_reason = is_array($conflict_state) && isset($conflict_state['reason']) ? (string) $conflict_state['reason'] : '';
        $conflict = $this->build_post_summary($conflict_post);
        $suggested_slug = null;

        if (is_array($conflict)) {
            $conflict['typeMismatch'] = ($conflict['wpType'] !== $type);
            if ($conflict_reason !== '') {
                $conflict['reason'] = $conflict_reason;
            }
            $suggested_slug = $this->suggest_available_slug($type, $slug, $exclude_wp_id);
        }

        return array(
            'ok' => true,
            'slug' => $slug,
            'exists' => $conflict_post ? true : false,
            'conflict' => $conflict,
            'suggestedSlug' => $suggested_slug,
        );
    }

    public function upsert($payload) {
        $type = isset($payload['type']) ? sanitize_text_field((string) $payload['type']) : '';
        if (!in_array($type, array('post', 'page'), true)) {
            return new WP_Error('massic_invalid_type', 'Invalid content type', array('status' => 400));
        }

        $title = isset($payload['title']) ? sanitize_text_field((string) $payload['title']) : '';
        $content_html = isset($payload['contentHtml']) ? (string) $payload['contentHtml'] : '';

        if (!$title || !$content_html) {
            return new WP_Error('massic_missing_fields', 'Title and contentHtml are required', array('status' => 400));
        }

        $status = $this->sanitize_status(isset($payload['status']) ? $payload['status'] : 'draft');
        $raw_slug = isset($payload['slug']) ? trim((string) $payload['slug']) : '';
        $slug = isset($payload['slug']) ? $this->normalize_slug_for_type($type, (string) $payload['slug']) : '';
        if ($raw_slug !== '' && $slug === '') {
            $invalid_message = ($type === 'post')
                ? 'Blog slug must be a single segment and cannot include nested "/" paths'
                : 'Slug must contain at least one valid segment and cannot be root "/"';
            return new WP_Error('massic_invalid_slug', $invalid_message, array('status' => 400));
        }
        $excerpt = isset($payload['excerpt']) ? sanitize_textarea_field((string) $payload['excerpt']) : '';
        $publish_at = isset($payload['publishAt']) ? sanitize_text_field((string) $payload['publishAt']) : '';
        $head = isset($payload['head']) ? $this->sanitize_head($payload['head']) : array();
        $featured_image = array_key_exists('featuredImage', $payload)
            ? $this->sanitize_featured_image($payload['featuredImage'])
            : null;
        if (is_wp_error($featured_image)) {
            return $featured_image;
        }
        $massic_css_overrides = isset($payload['massicCssOverrides']) ? $payload['massicCssOverrides'] : array();
        $required_page_template_file = '';
        if ($type === 'page') {
            $template_status = $this->get_required_page_template_status();
            if (empty($template_status['exists']) || empty($template_status['templateFile'])) {
                return $this->missing_required_page_template_error();
            }
            $required_page_template_file = sanitize_text_field((string) $template_status['templateFile']);
        }
        $clean_content_html = $this->strip_stale_massic_inline_css_text($content_html);
        $clean_content_html = $this->strip_legacy_broken_massic_css_text($clean_content_html);
        $clean_content_html = $this->strip_style_tags($clean_content_html);
        $sanitized_content_html = wp_kses($clean_content_html, $this->get_allowed_html_for_massic_content());
        $needs_unfiltered_save = $this->contains_massic_markup($sanitized_content_html);
        $prepared_content_html = $this->build_published_content_html($sanitized_content_html, $massic_css_overrides, $type);

        $post_arr = array(
            'post_type' => $type,
            'post_title' => $title,
            'post_content' => $prepared_content_html,
            'post_excerpt' => $excerpt,
            'post_status' => $status,
        );

        if ($publish_at) {
            $dt = strtotime($publish_at);
            if ($dt !== false) {
                $post_arr['post_date'] = gmdate('Y-m-d H:i:s', $dt);
                $post_arr['post_date_gmt'] = gmdate('Y-m-d H:i:s', $dt);
            }
        }

        $wp_id = isset($payload['wpId']) ? absint($payload['wpId']) : 0;

        if (array_key_exists('forceReplace', $payload)) {
            return new WP_Error('massic_force_replace_disabled', 'forceReplace is no longer supported. Use a unique slug.', array('status' => 400));
        }

        if ($slug) {
            $conflict_state = $this->find_slug_conflict($type, $slug, $wp_id);
            $conflict_post = is_array($conflict_state) && isset($conflict_state['post']) ? $conflict_state['post'] : null;
            $conflict_reason = is_array($conflict_state) && isset($conflict_state['reason']) ? (string) $conflict_state['reason'] : '';
            if ($conflict_post) {
                $conflict_summary = $this->build_post_summary($conflict_post);
                $type_mismatch = isset($conflict_summary['wpType']) && $conflict_summary['wpType'] !== $type;
                $is_parent_type_conflict = ($conflict_reason === 'parent_type_conflict');
                $message = $is_parent_type_conflict
                    ? 'Nested page path is blocked because a parent segment is not a page'
                    : ($type_mismatch ? 'Slug already exists with a different content type' : 'Slug already exists');

                return new WP_Error('slug_conflict', $message, array(
                    'status' => 409,
                    'slug' => $slug,
                    'typeMismatch' => $type_mismatch ? true : false,
                    'suggestedSlug' => $this->suggest_available_slug($type, $slug, $wp_id),
                    'conflict' => $conflict_summary,
                    'reason' => $conflict_reason !== '' ? $conflict_reason : 'slug_exists',
                ));
            }

            $slug_apply_error = $this->apply_slug_to_post_arr($type, $slug, $post_arr, $wp_id);
            if (is_wp_error($slug_apply_error)) {
                return $slug_apply_error;
            }
        }

        if ($wp_id > 0) {
            $existing = get_post($wp_id);
            $can_update_existing = $existing && $existing->post_type === $type;

            if ($can_update_existing) {
                // Allow republish of previously trashed content.
                if ($existing->post_status === 'trash') {
                    $restored = wp_untrash_post($wp_id);
                    if (!$restored) {
                        return new WP_Error('massic_restore_failed', 'Failed to restore trashed content', array('status' => 500));
                    }
                }

                $post_arr['ID'] = $wp_id;
                if ($needs_unfiltered_save) {
                    $result_id = $this->run_with_wp_kses_filters_disabled(function() use ($post_arr) {
                        return wp_update_post($post_arr, true);
                    });
                } else {
                    $result_id = wp_update_post($post_arr, true);
                }
            } else {
                // Stale or invalid wpId mapping: create fresh content instead of failing publish.
                if ($needs_unfiltered_save) {
                    $result_id = $this->run_with_wp_kses_filters_disabled(function() use ($post_arr) {
                        return wp_insert_post($post_arr, true);
                    });
                } else {
                    $result_id = wp_insert_post($post_arr, true);
                }
            }
        } else {
            if ($needs_unfiltered_save) {
                $result_id = $this->run_with_wp_kses_filters_disabled(function() use ($post_arr) {
                    return wp_insert_post($post_arr, true);
                });
            } else {
                $result_id = wp_insert_post($post_arr, true);
            }
        }

        if (is_wp_error($result_id)) {
            return new WP_Error('massic_upsert_failed', $result_id->get_error_message(), array('status' => 500));
        }

        if ($slug && $type === 'post') {
            $this->persist_full_slug_as_post_name($result_id, $slug);
        }

        if ($type === 'page' && $required_page_template_file !== '') {
            update_post_meta($result_id, '_wp_page_template', $required_page_template_file);
        }

        update_post_meta($result_id, self::META_HEAD_PAYLOAD, wp_json_encode($head));
        $this->persist_head_meta_keys($result_id, $type, $head);

        if (array_key_exists('featuredImage', $payload)) {
            $featured_image_result = $this->sync_featured_image_to_post($result_id, $type, $featured_image);
            if (is_wp_error($featured_image_result)) {
                return $featured_image_result;
            }
        }

        $result_post = get_post($result_id);
        $result_slug = '';
        if ($result_post) {
            $result_slug = $this->get_post_slug_path($result_post);
        }
        if ($result_slug === '' && $slug) {
            $result_slug = $this->normalize_slug_path($slug);
        }

        return array(
            'ok' => true,
            'wpId' => (int) $result_id,
            'permalink' => get_permalink($result_id),
            'editUrl' => admin_url('post.php?post=' . intval($result_id) . '&action=edit'),
            'status' => get_post_status($result_id),
            'wpType' => get_post_type($result_id),
            'slug' => $result_slug !== '' ? $result_slug : null,
        );
    }

    public function unpublish($payload) {
        $wp_id = isset($payload['wpId']) ? absint($payload['wpId']) : 0;
        if ($wp_id <= 0) {
            return new WP_Error('massic_missing_wp_id', 'wpId is required', array('status' => 400));
        }

        $post = get_post($wp_id);
        if (!$post || !in_array($post->post_type, array('post', 'page'), true)) {
            return new WP_Error('massic_invalid_wp_id', 'Invalid wpId', array('status' => 404));
        }

        $target_status = isset($payload['targetStatus']) ? sanitize_text_field((string) $payload['targetStatus']) : 'draft';
        if (!in_array($target_status, array('draft', 'trash'), true)) {
            $target_status = 'draft';
        }

        if ($target_status === 'trash') {
            if ($post->post_status !== 'trash') {
                $trashed = wp_trash_post($wp_id);
                if (!$trashed) {
                    return new WP_Error('massic_unpublish_failed', 'Failed to move content to trash', array('status' => 500));
                }
            }

            return array(
                'ok' => true,
                'wpId' => (int) $wp_id,
                'wpType' => get_post_type($wp_id),
                'status' => 'trash',
                'permalink' => null,
                'editUrl' => admin_url('post.php?post=' . intval($wp_id) . '&action=edit'),
            );
        }

        if ($post->post_status === 'trash') {
            $restored = wp_untrash_post($wp_id);
            if (!$restored) {
                return new WP_Error('massic_unpublish_failed', 'Failed to restore content from trash', array('status' => 500));
            }
        }

        $post_arr = array(
            'ID' => $wp_id,
            'post_status' => 'draft',
        );
        $updated = wp_update_post($post_arr, true);
        if (is_wp_error($updated) || !$updated) {
            return new WP_Error('massic_unpublish_failed', 'Failed to move content to draft', array('status' => 500));
        }

        return array(
            'ok' => true,
            'wpId' => (int) $wp_id,
            'wpType' => get_post_type($wp_id),
            'status' => 'draft',
            'permalink' => null,
            'editUrl' => admin_url('post.php?post=' . intval($wp_id) . '&action=edit'),
        );
    }
}
