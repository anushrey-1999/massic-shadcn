<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Admin {
    public function init() {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_post_massic_oauth_start', array($this, 'handle_oauth_start'));
    }

    public function register_menu() {
        add_options_page(
            'Massic Connector',
            'Massic Connector',
            'manage_options',
            'massic-wp-connector',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting('massic_connector_group', Massic_Options::OPTION_SITE_ID, array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));

        register_setting('massic_connector_group', Massic_Options::OPTION_PAIRING_CODE, array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));

        register_setting('massic_connector_group', Massic_Options::OPTION_CLIENT_SECRET, array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));

        register_setting('massic_connector_group', Massic_Options::OPTION_NONCE_TTL, array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 300,
        ));
    }

    public function handle_oauth_start() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'massic-wp-connector'));
        }

        check_admin_referer('massic_oauth_start');

        $backend_base = Massic_Options::get_backend_base();
        if (!$backend_base) {
            $this->redirect_with_notice('Connection is not available right now. Please contact support.', 'error');
        }

        $site_id = Massic_Options::get_site_id();
        if (!$site_id) {
            $this->redirect_with_notice('Could not start connection. Please refresh and try again.', 'error');
        }

        if (!Massic_Options::get_client_secret()) {
            Massic_Options::rotate_client_secret();
        }

        $state = wp_generate_password(40, false, false);
        $finalize_token = wp_generate_password(56, false, false);
        $return_url = admin_url('admin.php?page=massic-wp-connector');

        Massic_Options::create_connect_session(
            $state,
            $finalize_token,
            $return_url,
            get_current_user_id()
        );

        $start_url = rtrim($backend_base, '/') . '/api/cms/wordpress/oauth/start';
        $redirect_url = add_query_arg(array(
            'siteUrl' => site_url(),
            'siteId' => $site_id,
            'state' => $state,
            'finalizeToken' => $finalize_token,
            'returnUrl' => $return_url,
        ), $start_url);

        // Redirect to configured Massic backend domain (can be external to WP host).
        wp_redirect($redirect_url);
        exit;
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $connection_state = Massic_Options::get_connection_state();
        $connection_updated_at = Massic_Options::get_connection_updated_at();
        $connection_updated_at_readable = $this->format_datetime_for_admin($connection_updated_at);

        $notice_message = sanitize_text_field((string) ($_GET['massic_notice'] ?? ''));
        $notice_type = sanitize_text_field((string) ($_GET['massic_notice_type'] ?? 'success'));
        ?>
        <div class="wrap">
            <h1>Massic WordPress Connector</h1>

            <?php if ($notice_message) : ?>
                <div class="notice <?php echo $notice_type === 'error' ? 'notice-error' : 'notice-success'; ?> is-dismissible">
                    <p><?php echo esc_html($notice_message); ?></p>
                </div>
            <?php endif; ?>

            <div style="margin: 12px 0 18px; padding: 10px 12px; border: 1px solid #dcdcde; border-radius: 6px; background: #fff;">
                <p style="margin:0 0 4px;"><strong>Connection Status:</strong>
                    <?php if ($connection_state === 'connected') : ?>
                        <span style="color:#008a20;">Connected</span>
                    <?php else : ?>
                        <span style="color:#646970;">Disconnected</span>
                    <?php endif; ?>
                </p>
                <?php if (!empty($connection_updated_at)) : ?>
                    <p style="margin:0; color:#646970;">
                        <strong>Last Updated:</strong>
                        <span title="<?php echo esc_attr($connection_updated_at); ?>">
                            <?php echo esc_html($connection_updated_at_readable); ?>
                        </span>
                    </p>
                <?php endif; ?>
            </div>

            <h2>Connect</h2>
            <?php if ($connection_state === 'connected') : ?>
                <div style="margin-bottom:18px; padding:10px 12px; border:1px solid #dcdcde; border-radius:6px; background:#f6f7f7;">
                    <p style="margin:0; color:#1d2327;"><strong>Already connected.</strong> No further action is required.</p>
                </div>
            <?php else : ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:18px;">
                    <input type="hidden" name="action" value="massic_oauth_start" />
                    <?php wp_nonce_field('massic_oauth_start'); ?>
                    <button type="submit" class="button button-primary">
                        Connect to Massic (Recommended)
                    </button>
                </form>
            <?php endif; ?>

            <details>
                <summary style="cursor:pointer;"><strong>Manual Setup (Advanced)</strong></summary>
                <form method="post" action="options.php">
                    <?php settings_fields('massic_connector_group'); ?>
                    <?php do_settings_sections('massic_connector_group'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>">Site ID</label></th>
                            <td>
                                <input
                                    id="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>"
                                    name="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>"
                                    type="text"
                                    class="regular-text"
                                    value="<?php echo esc_attr(Massic_Options::get_site_id()); ?>"
                                />
                                <button
                                    type="button"
                                    class="button button-secondary"
                                    style="margin-left:8px;"
                                    onclick="massicCopyValue('<?php echo esc_js(Massic_Options::OPTION_SITE_ID); ?>', this)"
                                >
                                    Copy
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>">Pairing Code</label></th>
                            <td>
                                <input
                                    id="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>"
                                    name="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>"
                                    type="text"
                                    class="regular-text"
                                    value="<?php echo esc_attr(Massic_Options::get_pairing_code()); ?>"
                                />
                                <button
                                    type="button"
                                    class="button button-secondary"
                                    style="margin-left:8px;"
                                    onclick="massicCopyValue('<?php echo esc_js(Massic_Options::OPTION_PAIRING_CODE); ?>', this)"
                                >
                                    Copy
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>">Client Secret</label></th>
                            <td>
                                <input
                                    id="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>"
                                    name="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>"
                                    type="password"
                                    class="regular-text"
                                    value="<?php echo esc_attr(Massic_Options::get_client_secret()); ?>"
                                    autocomplete="new-password"
                                />
                                <button
                                    type="button"
                                    class="button button-secondary"
                                    style="margin-left:8px;"
                                    onclick="massicCopyValue('<?php echo esc_js(Massic_Options::OPTION_CLIENT_SECRET); ?>', this)"
                                >
                                    Copy
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_NONCE_TTL); ?>">Nonce TTL (seconds)</label></th>
                            <td><input name="<?php echo esc_attr(Massic_Options::OPTION_NONCE_TTL); ?>" type="number" min="60" max="3600" class="small-text" value="<?php echo esc_attr(Massic_Options::get_nonce_ttl()); ?>" /></td>
                        </tr>
                    </table>
                    <?php submit_button('Save Manual Settings'); ?>
                </form>
            </details>
        </div>
        <script>
                function massicCopyValue(inputId, buttonEl) {
                    var input = document.getElementById(inputId);
                    if (!input) return;

                    var value = input.value || '';
                    if (!value) return;

                    function markCopied() {
                        var original = buttonEl.textContent;
                        buttonEl.textContent = 'Copied';
                        setTimeout(function () {
                            buttonEl.textContent = original;
                        }, 1200);
                    }

                    function fallbackCopy() {
                        var originalType = input.type;
                        if (originalType === 'password') {
                            input.type = 'text';
                        }
                        input.select();
                        document.execCommand('copy');
                        if (originalType === 'password') {
                            input.type = originalType;
                        }
                        markCopied();
                    }

                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(value).then(markCopied).catch(fallbackCopy);
                        return;
                    }

                    fallbackCopy();
                }
        </script>
        <?php
    }

    private function format_datetime_for_admin($value) {
        $raw = trim((string) $value);
        if (!$raw) {
            return '';
        }

        $timestamp = strtotime($raw);
        if (!$timestamp) {
            return $raw;
        }

        $absolute = wp_date('M j, Y g:i A T', $timestamp);
        $now = time();
        $distance = human_time_diff($timestamp, $now);
        $relative = $timestamp <= $now ? ($distance . ' ago') : ('in ' . $distance);

        return $absolute . ' (' . $relative . ')';
    }

    private function redirect_with_notice($message, $type = 'success') {
        $redirect_url = add_query_arg(array(
            'page' => 'massic-wp-connector',
            'massic_notice' => (string) $message,
            'massic_notice_type' => $type === 'error' ? 'error' : 'success',
        ), admin_url('options-general.php'));

        wp_safe_redirect($redirect_url);
        exit;
    }
}
