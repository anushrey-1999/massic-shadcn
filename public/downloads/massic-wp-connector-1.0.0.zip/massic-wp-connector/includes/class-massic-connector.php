<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Connector {
    public function init() {
        $security = new Massic_Security();
        $content = new Massic_Content();
        $rest = new Massic_Rest($security, $content);
        $head = new Massic_Head();
        $preview = new Massic_Preview();
        $admin = new Massic_Admin();

        $rest->init();
        $head->init();
        $preview->init();
        $admin->init();
    }
}
