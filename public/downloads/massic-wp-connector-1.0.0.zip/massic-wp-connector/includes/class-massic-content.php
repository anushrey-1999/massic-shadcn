<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Content {
    const META_HEAD_PAYLOAD = '_massic_head_payload';
    const INLINE_CSS_ASSET_PATH = 'assets/wp-css-component-library.css';
    const INLINE_CSS_ATTR = 'data-massic-inline';
    const INLINE_CSS_ATTR_VALUE = '1';

    private function sanitize_status($status) {
        $allowed = array('draft', 'pending', 'publish', 'private', 'future');
        $value = sanitize_text_field((string) $status);
        if (!$value) {
            return 'draft';
        }

        if (!in_array($value, $allowed, true)) {
            return 'draft';
        }

        return $value;
    }

    private function sanitize_head($head) {
        if (!is_array($head)) {
            return array();
        }
        return $head;
    }

    private function contains_massic_markup($html) {
        if (!is_string($html) || $html === '') {
            return false;
        }

        if (stripos($html, 'massic-content') !== false) {
            return true;
        }

        return preg_match('/class\s*=\s*["\'][^"\']*massic-[^"\']*["\']/i', $html) === 1;
    }

    private function strip_style_tags($html) {
        if (!is_string($html) || $html === '') {
            return '';
        }

        $next = preg_replace('/<style\b[^>]*>.*?<\/style>/is', '', $html);
        if (!is_string($next)) {
            return $html;
        }

        return trim($next);
    }

    private function strip_stale_massic_inline_css_text($html) {
        if (!is_string($html) || $html === '') {
            return '';
        }

        $next = preg_replace(
            '/\/\*\s*MASSIC_INLINE_CSS_START\s*\*\/[\s\S]*?\/\*\s*MASSIC_INLINE_CSS_END\s*\*\//i',
            '',
            $html
        );

        if (!is_string($next)) {
            return $html;
        }

        return trim($next);
    }

    private function strip_legacy_broken_massic_css_text($html) {
        if (!is_string($html) || $html === '') {
            return '';
        }

        $legacy_marker = 'Neutral defaults only: common on US local-business WordPress themes.';
        if (strpos($html, $legacy_marker) === false) {
            return $html;
        }

        $start = strpos($html, '.massic-content {');
        if ($start === false) {
            return $html;
        }

        $next_tag = strpos($html, '<', $start + 1);
        if ($next_tag === false) {
            return trim(substr($html, 0, $start));
        }

        $prefix = substr($html, 0, $start);
        $suffix = substr($html, $next_tag);

        return trim($prefix . "\n" . $suffix);
    }

    private function load_base_massic_css() {
        static $cached_css = null;

        if ($cached_css !== null) {
            return $cached_css;
        }

        $asset_path = MASSIC_WP_CONNECTOR_PATH . self::INLINE_CSS_ASSET_PATH;
        if (!is_readable($asset_path)) {
            $cached_css = '';
            return $cached_css;
        }

        $raw = file_get_contents($asset_path); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        if (!is_string($raw)) {
            $cached_css = '';
            return $cached_css;
        }

        $raw = trim($raw);
        if ($raw === '' || strlen($raw) > 300000) {
            $cached_css = '';
            return $cached_css;
        }

        $cached_css = $raw;
        return $cached_css;
    }

    private function get_css_override_allowlist() {
        return array(
            '--massic-primary' => 'color',
            '--massic-text' => 'color',
            '--massic-muted' => 'color',
            '--massic-bg' => 'color',
            '--massic-surface' => 'color',
            '--massic-primary-contrast' => 'color',
            '--massic-font-sans' => 'fontFamily',
            '--massic-font-heading' => 'fontFamily',
            '--massic-text-base' => 'size',
            '--massic-line' => 'lineHeight',
            '--massic-h1' => 'size',
            '--massic-h2' => 'size',
            '--massic-h3' => 'size',
        );
    }

    private function sanitize_css_override_value($value, $value_type) {
        $next = trim((string) $value);
        if ($next === '') {
            return '';
        }

        if (
            preg_match('/[{};<>\\\\]/', $next) === 1 ||
            strpos($next, '/*') !== false ||
            strpos($next, '*/') !== false
        ) {
            return '';
        }

        if ($value_type === 'color') {
            return preg_match('/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $next) === 1 ? strtolower($next) : '';
        }

        if ($value_type === 'size') {
            return preg_match('/^-?(?:\d+|\d*\.\d+)(?:px|rem|em|%|vh|vw|vmin|vmax|ch|ex|pt)$/', $next) === 1 ? $next : '';
        }

        if ($value_type === 'lineHeight') {
            if (preg_match('/^(?:\d+|\d*\.\d+)$/', $next) === 1) {
                return $next;
            }
            return preg_match('/^(?:\d+|\d*\.\d+)(?:px|rem|em|%)$/', $next) === 1 ? $next : '';
        }

        if ($value_type === 'fontFamily') {
            return (strlen($next) <= 180 && preg_match('/^[a-zA-Z0-9\s,"\'-]+$/', $next) === 1) ? $next : '';
        }

        return '';
    }

    private function normalize_css_overrides($input) {
        if (!is_array($input)) {
            return array();
        }

        $allowed = $this->get_css_override_allowlist();
        $normalized = array();

        foreach ($input as $key => $value) {
            $var_name = sanitize_text_field((string) $key);
            if (!isset($allowed[$var_name])) {
                continue;
            }

            $sanitized = $this->sanitize_css_override_value($value, $allowed[$var_name]);
            if ($sanitized === '') {
                continue;
            }

            $normalized[$var_name] = $sanitized;
        }

        ksort($normalized);
        return $normalized;
    }

    private function build_css_override_block($input) {
        $overrides = $this->normalize_css_overrides($input);
        if (empty($overrides)) {
            return '';
        }

        $lines = array('.massic-content {');
        foreach ($overrides as $var_name => $value) {
            $lines[] = '  ' . $var_name . ': ' . $value . ';';
        }
        $lines[] = '}';

        return implode("\n", $lines);
    }

    private function minify_inline_css($css) {
        if (!is_string($css) || $css === '') {
            return '';
        }

        $next = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
        if (!is_string($next)) {
            $next = $css;
        }

        $next = str_replace(array("\r\n", "\r", "\n", "\t"), ' ', $next);
        $next = preg_replace('/\s+/', ' ', $next);
        if (!is_string($next)) {
            return '';
        }

        $next = preg_replace('/\s*([{}:;,])\s*/', '$1', $next);
        if (!is_string($next)) {
            return '';
        }

        return trim($next);
    }

    private function build_inline_css_html($overrides) {
        $base_css = $this->load_base_massic_css();
        if ($base_css === '') {
            return '';
        }

        $chunks = array($base_css);
        $override_block = $this->build_css_override_block($overrides);
        if ($override_block !== '') {
            $chunks[] = $override_block;
        }

        $css = implode("\n\n", $chunks);
        $css = $this->minify_inline_css($css);
        if ($css === '') {
            return '';
        }

        $css = '/*MASSIC_INLINE_CSS_START*/' . $css . '/*MASSIC_INLINE_CSS_END*/';

        return '<style type="text/css" ' . self::INLINE_CSS_ATTR . '="' . self::INLINE_CSS_ATTR_VALUE . '">'
            . $css
            . '</style>';
    }

    private function build_published_content_html($content_html, $massic_css_overrides) {
        $clean_html = $this->strip_style_tags($content_html);
        if (!$this->contains_massic_markup($clean_html)) {
            return $clean_html;
        }

        $inline_css = $this->build_inline_css_html($massic_css_overrides);
        if ($inline_css === '') {
            return $clean_html;
        }

        return $inline_css . $clean_html;
    }

    private function run_with_wp_kses_filters_disabled($callback) {
        $filters = array(
            'content_save_pre',
            'excerpt_save_pre',
            'content_filtered_save_pre',
        );

        $removed = array();
        foreach ($filters as $filter_name) {
            $has_filter = has_filter($filter_name, 'wp_filter_post_kses');
            $removed[$filter_name] = ($has_filter !== false) ? (int) $has_filter : false;
            if ($removed[$filter_name] !== false) {
                remove_filter($filter_name, 'wp_filter_post_kses');
            }
        }

        try {
            return call_user_func($callback);
        } finally {
            foreach ($filters as $filter_name) {
                if ($removed[$filter_name] !== false) {
                    add_filter($filter_name, 'wp_filter_post_kses', (int) $removed[$filter_name], 1);
                }
            }
        }
    }

    public function upsert($payload) {
        $type = isset($payload['type']) ? sanitize_text_field((string) $payload['type']) : '';
        if (!in_array($type, array('post', 'page'), true)) {
            return new WP_Error('massic_invalid_type', 'Invalid content type', array('status' => 400));
        }

        $title = isset($payload['title']) ? sanitize_text_field((string) $payload['title']) : '';
        $content_html = isset($payload['contentHtml']) ? (string) $payload['contentHtml'] : '';

        if (!$title || !$content_html) {
            return new WP_Error('massic_missing_fields', 'Title and contentHtml are required', array('status' => 400));
        }

        $status = $this->sanitize_status(isset($payload['status']) ? $payload['status'] : 'draft');
        $slug = isset($payload['slug']) ? sanitize_title((string) $payload['slug']) : '';
        $excerpt = isset($payload['excerpt']) ? sanitize_textarea_field((string) $payload['excerpt']) : '';
        $publish_at = isset($payload['publishAt']) ? sanitize_text_field((string) $payload['publishAt']) : '';
        $head = isset($payload['head']) ? $this->sanitize_head($payload['head']) : array();
        $massic_css_overrides = isset($payload['massicCssOverrides']) ? $payload['massicCssOverrides'] : array();
        $clean_content_html = $this->strip_stale_massic_inline_css_text($content_html);
        $clean_content_html = $this->strip_legacy_broken_massic_css_text($clean_content_html);
        $clean_content_html = $this->strip_style_tags($clean_content_html);
        $sanitized_content_html = wp_kses_post($clean_content_html);
        $needs_unfiltered_save = $this->contains_massic_markup($sanitized_content_html);
        $prepared_content_html = $this->build_published_content_html($sanitized_content_html, $massic_css_overrides);

        $post_arr = array(
            'post_type' => $type,
            'post_title' => $title,
            'post_content' => $prepared_content_html,
            'post_excerpt' => $excerpt,
            'post_status' => $status,
        );

        if ($slug) {
            $post_arr['post_name'] = $slug;
        }

        if ($publish_at) {
            $dt = strtotime($publish_at);
            if ($dt !== false) {
                $post_arr['post_date'] = gmdate('Y-m-d H:i:s', $dt);
                $post_arr['post_date_gmt'] = gmdate('Y-m-d H:i:s', $dt);
            }
        }

        $wp_id = isset($payload['wpId']) ? absint($payload['wpId']) : 0;

        if ($wp_id > 0) {
            $existing = get_post($wp_id);
            $can_update_existing = $existing && $existing->post_type === $type;

            if ($can_update_existing) {
                // Allow republish of previously trashed content.
                if ($existing->post_status === 'trash') {
                    $restored = wp_untrash_post($wp_id);
                    if (!$restored) {
                        return new WP_Error('massic_restore_failed', 'Failed to restore trashed content', array('status' => 500));
                    }
                }

                $post_arr['ID'] = $wp_id;
                if ($needs_unfiltered_save) {
                    $result_id = $this->run_with_wp_kses_filters_disabled(function() use ($post_arr) {
                        return wp_update_post($post_arr, true);
                    });
                } else {
                    $result_id = wp_update_post($post_arr, true);
                }
            } else {
                // Stale or invalid wpId mapping: create fresh content instead of failing publish.
                if ($needs_unfiltered_save) {
                    $result_id = $this->run_with_wp_kses_filters_disabled(function() use ($post_arr) {
                        return wp_insert_post($post_arr, true);
                    });
                } else {
                    $result_id = wp_insert_post($post_arr, true);
                }
            }
        } else {
            if ($needs_unfiltered_save) {
                $result_id = $this->run_with_wp_kses_filters_disabled(function() use ($post_arr) {
                    return wp_insert_post($post_arr, true);
                });
            } else {
                $result_id = wp_insert_post($post_arr, true);
            }
        }

        if (is_wp_error($result_id)) {
            return new WP_Error('massic_upsert_failed', $result_id->get_error_message(), array('status' => 500));
        }

        update_post_meta($result_id, self::META_HEAD_PAYLOAD, wp_json_encode($head));

        return array(
            'ok' => true,
            'wpId' => (int) $result_id,
            'permalink' => get_permalink($result_id),
            'editUrl' => admin_url('post.php?post=' . intval($result_id) . '&action=edit'),
            'status' => get_post_status($result_id),
            'wpType' => get_post_type($result_id),
        );
    }

    public function unpublish($payload) {
        $wp_id = isset($payload['wpId']) ? absint($payload['wpId']) : 0;
        if ($wp_id <= 0) {
            return new WP_Error('massic_missing_wp_id', 'wpId is required', array('status' => 400));
        }

        $post = get_post($wp_id);
        if (!$post || !in_array($post->post_type, array('post', 'page'), true)) {
            return new WP_Error('massic_invalid_wp_id', 'Invalid wpId', array('status' => 404));
        }

        $target_status = isset($payload['targetStatus']) ? sanitize_text_field((string) $payload['targetStatus']) : 'draft';
        if (!in_array($target_status, array('draft', 'trash'), true)) {
            $target_status = 'draft';
        }

        if ($target_status === 'trash') {
            if ($post->post_status !== 'trash') {
                $trashed = wp_trash_post($wp_id);
                if (!$trashed) {
                    return new WP_Error('massic_unpublish_failed', 'Failed to move content to trash', array('status' => 500));
                }
            }

            return array(
                'ok' => true,
                'wpId' => (int) $wp_id,
                'wpType' => get_post_type($wp_id),
                'status' => 'trash',
                'permalink' => null,
                'editUrl' => admin_url('post.php?post=' . intval($wp_id) . '&action=edit'),
            );
        }

        if ($post->post_status === 'trash') {
            $restored = wp_untrash_post($wp_id);
            if (!$restored) {
                return new WP_Error('massic_unpublish_failed', 'Failed to restore content from trash', array('status' => 500));
            }
        }

        $post_arr = array(
            'ID' => $wp_id,
            'post_status' => 'draft',
        );
        $updated = wp_update_post($post_arr, true);
        if (is_wp_error($updated) || !$updated) {
            return new WP_Error('massic_unpublish_failed', 'Failed to move content to draft', array('status' => 500));
        }

        return array(
            'ok' => true,
            'wpId' => (int) $wp_id,
            'wpType' => get_post_type($wp_id),
            'status' => 'draft',
            'permalink' => null,
            'editUrl' => admin_url('post.php?post=' . intval($wp_id) . '&action=edit'),
        );
    }
}
