<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Head {
    const META_HEAD_PAYLOAD = '_massic_head_payload';
    const META_SEO_TITLE = '_massic_meta_title';
    const META_SEO_DESCRIPTION = '_massic_meta_description';

    public function init() {
        add_action('wp_head', array($this, 'render_head'), 5);
        add_filter('pre_get_document_title', array($this, 'filter_document_title'), 20);
    }

    private function output_meta_name($name, $content) {
        if (!$content) {
            return;
        }
        echo '<meta name="' . esc_attr($name) . '" content="' . esc_attr($content) . '" />' . "\n";
    }

    private function output_meta_property($property, $content) {
        if (!$content) {
            return;
        }
        echo '<meta property="' . esc_attr($property) . '" content="' . esc_attr($content) . '" />' . "\n";
    }

    private function get_current_post_id() {
        if (!is_singular()) {
            return 0;
        }

        $post_id = get_queried_object_id();
        return $post_id ? (int) $post_id : 0;
    }

    private function get_head_payload($post_id) {
        if (!$post_id) {
            return array();
        }

        $raw = get_post_meta($post_id, self::META_HEAD_PAYLOAD, true);
        if (!$raw) {
            return array();
        }

        $head = json_decode($raw, true);
        return is_array($head) ? $head : array();
    }

    private function get_head_string($head, $key) {
        if (!is_array($head) || !isset($head[$key]) || !is_scalar($head[$key])) {
            return '';
        }

        return trim((string) $head[$key]);
    }

    private function get_post_meta_string($post_id, $meta_key) {
        if (!$post_id) {
            return '';
        }

        $value = get_post_meta($post_id, $meta_key, true);
        return is_scalar($value) ? trim((string) $value) : '';
    }

    public function filter_document_title($title) {
        $post_id = $this->get_current_post_id();
        if (!$post_id || get_post_type($post_id) !== 'post') {
            return $title;
        }

        $head = $this->get_head_payload($post_id);
        $seo_title = $this->get_head_string($head, 'seoTitle');
        if ($seo_title === '') {
            $seo_title = $this->get_post_meta_string($post_id, self::META_SEO_TITLE);
        }

        return $seo_title !== '' ? $seo_title : $title;
    }

    public function render_head() {
        $post_id = $this->get_current_post_id();
        if (!$post_id) {
            return;
        }

        $head = $this->get_head_payload($post_id);
        if (empty($head)) {
            return;
        }

        $is_blog_post = get_post_type($post_id) === 'post';
        $seo_title = $is_blog_post ? $this->get_head_string($head, 'seoTitle') : '';
        $meta_description = $this->get_head_string($head, 'metaDescription');
        $og_title = $this->get_head_string($head, 'ogTitle');
        $og_description = $this->get_head_string($head, 'ogDescription');
        $twitter_title = $this->get_head_string($head, 'twitterTitle');
        $twitter_description = $this->get_head_string($head, 'twitterDescription');

        if ($is_blog_post && $seo_title === '') {
            $seo_title = $this->get_post_meta_string($post_id, self::META_SEO_TITLE);
        }
        if ($is_blog_post && $meta_description === '') {
            $meta_description = $this->get_post_meta_string($post_id, self::META_SEO_DESCRIPTION);
        }
        if ($is_blog_post && $og_title === '') {
            $og_title = $seo_title;
        }
        if ($is_blog_post && $og_description === '') {
            $og_description = $meta_description;
        }
        if ($is_blog_post && $twitter_title === '') {
            $twitter_title = $seo_title;
        }
        if ($is_blog_post && $twitter_description === '') {
            $twitter_description = $meta_description;
        }

        if (!empty($head['canonicalUrl'])) {
            echo '<link rel="canonical" href="' . esc_url($head['canonicalUrl']) . '" />' . "\n";
        }

        $this->output_meta_name('description', $meta_description);
        $this->output_meta_name('robots', isset($head['robots']) ? $head['robots'] : '');

        $this->output_meta_property('og:title', $og_title);
        $this->output_meta_property('og:description', $og_description);

        if (!empty($head['ogImage'])) {
            $this->output_meta_property('og:image', $head['ogImage']);
        }

        $this->output_meta_name('twitter:card', isset($head['twitterCard']) ? $head['twitterCard'] : '');
        $this->output_meta_name('twitter:title', $twitter_title);
        $this->output_meta_name('twitter:description', $twitter_description);

        if (!empty($head['alternates']) && is_array($head['alternates'])) {
            foreach ($head['alternates'] as $alt) {
                if (!is_array($alt)) {
                    continue;
                }
                $href = !empty($alt['href']) ? esc_url($alt['href']) : '';
                $hreflang = !empty($alt['hreflang']) ? esc_attr($alt['hreflang']) : '';
                if ($href && $hreflang) {
                    echo '<link rel="alternate" href="' . $href . '" hreflang="' . $hreflang . '" />' . "\n";
                }
            }
        }

        if (!empty($head['metaTags']) && is_array($head['metaTags'])) {
            foreach ($head['metaTags'] as $meta) {
                if (!is_array($meta)) {
                    continue;
                }
                $name = !empty($meta['name']) ? sanitize_text_field($meta['name']) : '';
                $property = !empty($meta['property']) ? sanitize_text_field($meta['property']) : '';
                $content = !empty($meta['content']) ? sanitize_text_field($meta['content']) : '';
                if ($name && $content) {
                    $this->output_meta_name($name, $content);
                } elseif ($property && $content) {
                    $this->output_meta_property($property, $content);
                }
            }
        }

        if (!empty($head['linkTags']) && is_array($head['linkTags'])) {
            foreach ($head['linkTags'] as $link) {
                if (!is_array($link)) {
                    continue;
                }
                $rel = !empty($link['rel']) ? esc_attr($link['rel']) : '';
                $href = !empty($link['href']) ? esc_url($link['href']) : '';
                $type = !empty($link['type']) ? esc_attr($link['type']) : '';
                $sizes = !empty($link['sizes']) ? esc_attr($link['sizes']) : '';

                if (!$rel || !$href) {
                    continue;
                }

                echo '<link rel="' . $rel . '" href="' . $href . '"';
                if ($type) {
                    echo ' type="' . $type . '"';
                }
                if ($sizes) {
                    echo ' sizes="' . $sizes . '"';
                }
                echo ' />' . "\n";
            }
        }
    }
}
