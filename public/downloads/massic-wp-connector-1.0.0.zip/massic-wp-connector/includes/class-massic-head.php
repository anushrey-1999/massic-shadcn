<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Head {
    const META_HEAD_PAYLOAD = '_massic_head_payload';

    public function init() {
        add_action('wp_head', array($this, 'render_head'), 5);
    }

    private function output_meta_name($name, $content) {
        if (!$content) {
            return;
        }
        echo '<meta name="' . esc_attr($name) . '" content="' . esc_attr($content) . '" />' . "\n";
    }

    private function output_meta_property($property, $content) {
        if (!$content) {
            return;
        }
        echo '<meta property="' . esc_attr($property) . '" content="' . esc_attr($content) . '" />' . "\n";
    }

    public function render_head() {
        if (!is_singular()) {
            return;
        }

        $post_id = get_queried_object_id();
        if (!$post_id) {
            return;
        }

        $raw = get_post_meta($post_id, self::META_HEAD_PAYLOAD, true);
        if (!$raw) {
            return;
        }

        $head = json_decode($raw, true);
        if (!is_array($head)) {
            return;
        }

        if (!empty($head['canonicalUrl'])) {
            echo '<link rel="canonical" href="' . esc_url($head['canonicalUrl']) . '" />' . "\n";
        }

        $this->output_meta_name('description', isset($head['metaDescription']) ? $head['metaDescription'] : '');
        $this->output_meta_name('robots', isset($head['robots']) ? $head['robots'] : '');

        $this->output_meta_property('og:title', isset($head['ogTitle']) ? $head['ogTitle'] : '');
        $this->output_meta_property('og:description', isset($head['ogDescription']) ? $head['ogDescription'] : '');

        if (!empty($head['ogImage'])) {
            $this->output_meta_property('og:image', $head['ogImage']);
        }

        $this->output_meta_name('twitter:card', isset($head['twitterCard']) ? $head['twitterCard'] : '');
        $this->output_meta_name('twitter:title', isset($head['twitterTitle']) ? $head['twitterTitle'] : '');
        $this->output_meta_name('twitter:description', isset($head['twitterDescription']) ? $head['twitterDescription'] : '');

        if (!empty($head['alternates']) && is_array($head['alternates'])) {
            foreach ($head['alternates'] as $alt) {
                if (!is_array($alt)) {
                    continue;
                }
                $href = !empty($alt['href']) ? esc_url($alt['href']) : '';
                $hreflang = !empty($alt['hreflang']) ? esc_attr($alt['hreflang']) : '';
                if ($href && $hreflang) {
                    echo '<link rel="alternate" href="' . $href . '" hreflang="' . $hreflang . '" />' . "\n";
                }
            }
        }

        if (!empty($head['metaTags']) && is_array($head['metaTags'])) {
            foreach ($head['metaTags'] as $meta) {
                if (!is_array($meta)) {
                    continue;
                }
                $name = !empty($meta['name']) ? sanitize_text_field($meta['name']) : '';
                $property = !empty($meta['property']) ? sanitize_text_field($meta['property']) : '';
                $content = !empty($meta['content']) ? sanitize_text_field($meta['content']) : '';
                if ($name && $content) {
                    $this->output_meta_name($name, $content);
                } elseif ($property && $content) {
                    $this->output_meta_property($property, $content);
                }
            }
        }

        if (!empty($head['linkTags']) && is_array($head['linkTags'])) {
            foreach ($head['linkTags'] as $link) {
                if (!is_array($link)) {
                    continue;
                }
                $rel = !empty($link['rel']) ? esc_attr($link['rel']) : '';
                $href = !empty($link['href']) ? esc_url($link['href']) : '';
                $type = !empty($link['type']) ? esc_attr($link['type']) : '';
                $sizes = !empty($link['sizes']) ? esc_attr($link['sizes']) : '';

                if (!$rel || !$href) {
                    continue;
                }

                echo '<link rel="' . $rel . '" href="' . $href . '"';
                if ($type) {
                    echo ' type="' . $type . '"';
                }
                if ($sizes) {
                    echo ' sizes="' . $sizes . '"';
                }
                echo ' />' . "\n";
            }
        }
    }
}
