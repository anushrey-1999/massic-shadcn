<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Http {
    const LIFECYCLE_PATH = '/api/cms/wordpress/plugin/state';

    public static function notify_plugin_lifecycle($event, $event_at = '') {
        $event = sanitize_text_field((string) $event);
        if (!in_array($event, array('deactivated', 'uninstalled'), true)) {
            return new WP_Error('massic_lifecycle_invalid_event', 'Invalid lifecycle event');
        }

        $backend_base = Massic_Options::get_backend_base();
        if (!$backend_base) {
            return new WP_Error('massic_lifecycle_missing_backend', 'Massic backend base is not configured');
        }

        $site_id = Massic_Options::get_site_id();
        $client_secret = Massic_Options::get_client_secret();

        if (!$site_id || !$client_secret) {
            return new WP_Error('massic_lifecycle_missing_credentials', 'Missing site credentials for lifecycle sync');
        }

        if (!$event_at) {
            $event_at = gmdate('c');
        }

        $payload = array(
            'event' => $event,
            'eventAt' => sanitize_text_field((string) $event_at),
            'siteId' => $site_id,
            'siteUrl' => site_url(),
        );

        $body_raw = wp_json_encode($payload);
        $headers = self::build_signed_headers($site_id, $client_secret, 'POST', self::LIFECYCLE_PATH, $body_raw);

        $endpoint = rtrim($backend_base, '/') . self::LIFECYCLE_PATH;
        $response = wp_remote_post($endpoint, array(
            'timeout' => 8,
            'headers' => $headers,
            'body' => $body_raw,
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $status_code = (int) wp_remote_retrieve_response_code($response);
        if ($status_code < 200 || $status_code >= 300) {
            return new WP_Error('massic_lifecycle_http_error', 'Lifecycle sync request failed', array(
                'status' => $status_code,
                'body' => wp_remote_retrieve_body($response),
            ));
        }

        return true;
    }

    private static function build_signed_headers($site_id, $secret, $method, $path, $body_raw) {
        $timestamp = (string) time();

        try {
            $nonce = bin2hex(random_bytes(16));
        } catch (Exception $error) {
            $nonce = wp_generate_password(32, false, false);
        }

        $body_hash = hash('sha256', (string) $body_raw);
        $canonical = strtoupper((string) $method) . "\n" . $path . "\n" . $timestamp . "\n" . $nonce . "\n" . $body_hash;
        $signature = hash_hmac('sha256', $canonical, (string) $secret);

        return array(
            'Content-Type' => 'application/json',
            'X-Massic-SiteId' => (string) $site_id,
            'X-Massic-Timestamp' => $timestamp,
            'X-Massic-Nonce' => $nonce,
            'X-Massic-Signature' => $signature,
        );
    }
}
