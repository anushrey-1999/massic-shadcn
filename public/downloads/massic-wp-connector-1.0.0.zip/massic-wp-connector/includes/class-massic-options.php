<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Options {
    const OPTION_SITE_ID = 'massic_site_id';
    const OPTION_PAIRING_CODE = 'massic_pairing_code';
    const OPTION_CLIENT_SECRET = 'massic_client_secret';
    const OPTION_NONCE_TTL = 'massic_nonce_ttl';
    const OPTION_LAST_NONCE_CACHE = 'massic_last_nonce_cache';
    const OPTION_CONNECTION_STATE = 'massic_connection_state';
    const OPTION_CONNECTION_UPDATED_AT = 'massic_connection_updated_at';
    const OPTION_BACKEND_BASE = 'massic_backend_base';
    const OPTION_APP_BASE = 'massic_app_base';

    const CONNECT_SESSION_TRANSIENT_KEY = 'massic_connect_session';
    const CONNECT_SESSION_TTL_SECONDS = 600;

    public static function get_site_id() {
        return (string) get_option(self::OPTION_SITE_ID, '');
    }

    public static function get_pairing_code() {
        return (string) get_option(self::OPTION_PAIRING_CODE, '');
    }

    public static function get_client_secret() {
        return (string) get_option(self::OPTION_CLIENT_SECRET, '');
    }

    public static function get_backend_base() {
        if (defined('MASSIC_BACKEND_BASE') && MASSIC_BACKEND_BASE) {
            return self::normalize_base_url((string) MASSIC_BACKEND_BASE);
        }

        $env_backend = getenv('MASSIC_BACKEND_BASE');
        if ($env_backend) {
            return self::normalize_base_url((string) $env_backend);
        }

        // Backward compatibility for older plugin installs that saved this in wp_options.
        return self::normalize_base_url((string) get_option(self::OPTION_BACKEND_BASE, ''));
    }

    public static function get_app_base() {
        if (defined('MASSIC_APP_BASE') && MASSIC_APP_BASE) {
            return self::normalize_base_url((string) MASSIC_APP_BASE);
        }

        $env_app = getenv('MASSIC_APP_BASE');
        if ($env_app) {
            return self::normalize_base_url((string) $env_app);
        }

        // Backward compatibility for older plugin installs that saved this in wp_options.
        return self::normalize_base_url((string) get_option(self::OPTION_APP_BASE, ''));
    }

    public static function get_nonce_ttl() {
        $ttl = absint(get_option(self::OPTION_NONCE_TTL, 300));
        if ($ttl < 60) {
            return 60;
        }
        if ($ttl > 3600) {
            return 3600;
        }
        return $ttl;
    }

    public static function set_last_nonce_cache($nonce) {
        update_option(self::OPTION_LAST_NONCE_CACHE, sanitize_text_field($nonce));
    }

    public static function set_connection_state($connected, $event_at = '') {
        update_option(self::OPTION_CONNECTION_STATE, $connected ? 'connected' : 'disconnected');
        update_option(self::OPTION_CONNECTION_UPDATED_AT, sanitize_text_field((string) $event_at));
    }

    public static function get_connection_state() {
        return (string) get_option(self::OPTION_CONNECTION_STATE, 'disconnected');
    }

    public static function get_connection_updated_at() {
        return (string) get_option(self::OPTION_CONNECTION_UPDATED_AT, '');
    }

    public static function rotate_client_secret() {
        $secret = wp_generate_password(64, false, false);
        update_option(self::OPTION_CLIENT_SECRET, $secret);
        return $secret;
    }

    public static function rotate_pairing_code() {
        $pairing_code = wp_generate_password(16, false, false);
        update_option(self::OPTION_PAIRING_CODE, $pairing_code);
        return $pairing_code;
    }

    public static function create_connect_session($state, $finalize_token, $return_url, $initiated_by_user_id = 0) {
        $now = time();
        $payload = array(
            'state' => sanitize_text_field((string) $state),
            'finalizeTokenHash' => hash('sha256', (string) $finalize_token),
            'returnUrl' => esc_url_raw((string) $return_url),
            'initiatedByUserId' => absint($initiated_by_user_id),
            'createdAt' => gmdate('c', $now),
            'expiresAt' => $now + self::CONNECT_SESSION_TTL_SECONDS,
        );

        set_transient(self::CONNECT_SESSION_TRANSIENT_KEY, $payload, self::CONNECT_SESSION_TTL_SECONDS);
    }

    public static function get_connect_session() {
        $payload = get_transient(self::CONNECT_SESSION_TRANSIENT_KEY);
        if (!is_array($payload)) {
            return null;
        }

        return $payload;
    }

    public static function consume_connect_session($state, $finalize_token) {
        $payload = self::get_connect_session();
        if (!$payload) {
            return new WP_Error('massic_connect_session_missing', 'Connect session not found or expired', array('status' => 401));
        }

        $state_from_payload = sanitize_text_field((string) ($payload['state'] ?? ''));
        $expected_hash = sanitize_text_field((string) ($payload['finalizeTokenHash'] ?? ''));
        $expires_at = absint($payload['expiresAt'] ?? 0);

        if (!$state_from_payload || !$expected_hash || !$expires_at) {
            self::clear_connect_session();
            return new WP_Error('massic_connect_session_invalid', 'Connect session payload is invalid', array('status' => 401));
        }

        if (time() > $expires_at) {
            self::clear_connect_session();
            return new WP_Error('massic_connect_session_expired', 'Connect session has expired', array('status' => 410));
        }

        if (!hash_equals($state_from_payload, sanitize_text_field((string) $state))) {
            return new WP_Error('massic_connect_state_mismatch', 'Invalid connect state', array('status' => 401));
        }

        $received_hash = hash('sha256', (string) $finalize_token);
        if (!hash_equals($expected_hash, $received_hash)) {
            return new WP_Error('massic_connect_token_mismatch', 'Invalid finalize token', array('status' => 401));
        }

        self::clear_connect_session();

        return $payload;
    }

    public static function clear_connect_session() {
        delete_transient(self::CONNECT_SESSION_TRANSIENT_KEY);
    }

    private static function normalize_base_url($url) {
        $url = trim((string) $url);
        if (!$url) {
            return '';
        }

        $url = esc_url_raw($url);
        if (!$url) {
            return '';
        }

        return rtrim($url, '/');
    }
}
