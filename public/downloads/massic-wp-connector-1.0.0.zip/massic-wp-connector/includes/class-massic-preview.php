<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Preview {
    const QUERY_PREVIEW = 'massic_preview';
    const QUERY_TOKEN = 'massic_preview_token';

    public function init() {
        add_filter('query_vars', array($this, 'register_query_vars'));
        add_action('pre_get_posts', array($this, 'allow_draft_query')); 
        add_action('template_redirect', array($this, 'block_invalid_preview')); 
    }

    public function register_query_vars($vars) {
        $vars[] = self::QUERY_PREVIEW;
        $vars[] = self::QUERY_TOKEN;
        return $vars;
    }

    private function get_validated_post_id() {
        $preview = get_query_var(self::QUERY_PREVIEW);
        $token = sanitize_text_field((string) get_query_var(self::QUERY_TOKEN));
        $post_id = absint(get_query_var('p'));

        if (!$preview || !$token || $post_id <= 0) {
            return 0;
        }

        $payload = get_transient('massic_preview_token_' . md5($token));
        if (!is_array($payload) || empty($payload['post_id'])) {
            return 0;
        }

        if (intval($payload['post_id']) !== $post_id) {
            return 0;
        }

        return $post_id;
    }

    public function allow_draft_query($query) {
        if (is_admin() || !$query->is_main_query()) {
            return;
        }

        $post_id = $this->get_validated_post_id();
        if (!$post_id) {
            return;
        }

        $query->set('p', $post_id);
        $query->set('post_type', array('post', 'page'));
        $query->set('post_status', array('publish', 'draft', 'pending', 'private', 'future'));
    }

    public function block_invalid_preview() {
        $preview = get_query_var(self::QUERY_PREVIEW);
        if (!$preview) {
            return;
        }

        $post_id = $this->get_validated_post_id();
        if (!$post_id) {
            status_header(403);
            nocache_headers();
            wp_die(esc_html__('Invalid or expired preview token', 'massic-wp-connector'));
        }
    }
}
