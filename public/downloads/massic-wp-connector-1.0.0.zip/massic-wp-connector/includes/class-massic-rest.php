<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Rest {
    private $security;
    private $content;

    public function __construct(Massic_Security $security, Massic_Content $content) {
        $this->security = $security;
        $this->content = $content;
    }

    public function init() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route('massic/v1', '/connect/confirm', array(
            'methods' => 'POST',
            'callback' => array($this, 'connect_confirm'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('massic/v1', '/connect/state', array(
            'methods' => 'POST',
            'callback' => array($this, 'connect_state'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('massic/v1', '/connect/finalize', array(
            'methods' => 'POST',
            'callback' => array($this, 'connect_finalize'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('massic/v1', '/connect/disconnect', array(
            'methods' => 'POST',
            'callback' => array($this, 'connect_disconnect'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('massic/v1', '/connect/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'connect_status'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('massic/v1', '/style/theme', array(
            'methods' => 'POST',
            'callback' => array($this, 'style_theme'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('massic/v1', '/content/upsert', array(
            'methods' => 'POST',
            'callback' => array($this, 'content_upsert'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('massic/v1', '/content/unpublish', array(
            'methods' => 'POST',
            'callback' => array($this, 'content_unpublish'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('massic/v1', '/content/preview-link', array(
            'methods' => 'POST',
            'callback' => array($this, 'content_preview_link'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('massic/v1', '/content/slug-check', array(
            'methods' => 'POST',
            'callback' => array($this, 'content_slug_check'),
            'permission_callback' => '__return_true',
        ));
    }

    public function connect_confirm(WP_REST_Request $request) {
        $site_id = sanitize_text_field((string) $request->get_param('siteId'));
        $pairing_code = sanitize_text_field((string) $request->get_param('pairingCode'));
        $client_secret = sanitize_text_field((string) $request->get_param('clientSecret'));

        if (!$site_id || !$pairing_code) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'siteId and pairingCode are required',
            ), 400);
        }

        if ($site_id !== Massic_Options::get_site_id()) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'Invalid siteId',
            ), 401);
        }

        if ($pairing_code !== Massic_Options::get_pairing_code()) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'Invalid pairingCode',
            ), 401);
        }

        if (!$client_secret || $client_secret !== Massic_Options::get_client_secret()) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'Invalid clientSecret',
            ), 401);
        }

        Massic_Options::set_connection_state(true, gmdate('c'));

        return new WP_REST_Response(array(
            'ok' => true,
            'siteName' => get_bloginfo('name'),
            'siteId' => Massic_Options::get_site_id(),
        ), 200);
    }

    public function connect_state(WP_REST_Request $request) {
        $verified = $this->security->verify_signed_request($request, '/wp-json/massic/v1/connect/state');
        if (is_wp_error($verified)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => $verified->get_error_message(),
            ), (int) $verified->get_error_data()['status']);
        }

        $connected = filter_var($request->get_param('connected'), FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        if ($connected === null) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'connected boolean is required',
            ), 400);
        }

        $event_at = sanitize_text_field((string) $request->get_param('eventAt'));
        if (!$event_at) {
            $event_at = gmdate('c');
        }

        Massic_Options::set_connection_state($connected, $event_at);

        return new WP_REST_Response(array(
            'ok' => true,
            'connected' => (bool) $connected,
            'updatedAt' => $event_at,
        ), 200);
    }

    public function connect_finalize(WP_REST_Request $request) {
        $state = sanitize_text_field((string) $request->get_param('state'));
        $finalize_token = sanitize_text_field((string) $request->get_param('finalizeToken'));

        if (!$state || !$finalize_token) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'state and finalizeToken are required',
            ), 400);
        }

        $session = Massic_Options::consume_connect_session($state, $finalize_token);
        if (is_wp_error($session)) {
            $status = 401;
            $error_data = $session->get_error_data();
            if (is_array($error_data) && isset($error_data['status'])) {
                $status = (int) $error_data['status'];
            }

            return new WP_REST_Response(array(
                'ok' => false,
                'message' => $session->get_error_message(),
            ), $status);
        }

        $client_secret = Massic_Options::get_client_secret();
        if (!$client_secret) {
            $client_secret = Massic_Options::rotate_client_secret();
        }

        $connected_at = gmdate('c');
        Massic_Options::set_connection_state(true, $connected_at);

        return new WP_REST_Response(array(
            'ok' => true,
            'siteName' => get_bloginfo('name'),
            'siteId' => Massic_Options::get_site_id(),
            'clientSecret' => $client_secret,
            'connectedAt' => $connected_at,
            'initiatedByUserId' => (int) ($session['initiatedByUserId'] ?? 0),
        ), 200);
    }

    public function connect_disconnect(WP_REST_Request $request) {
        $verified = $this->security->verify_signed_request($request, '/wp-json/massic/v1/connect/disconnect');
        if (is_wp_error($verified)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => $verified->get_error_message(),
            ), (int) $verified->get_error_data()['status']);
        }

        $event_at = sanitize_text_field((string) $request->get_param('eventAt'));
        if (!$event_at) {
            $event_at = gmdate('c');
        }

        Massic_Options::set_connection_state(false, $event_at);
        Massic_Options::rotate_client_secret();
        Massic_Options::rotate_pairing_code();
        Massic_Options::clear_connect_session();

        return new WP_REST_Response(array(
            'ok' => true,
            'connected' => false,
            'updatedAt' => $event_at,
            'rotated' => true,
        ), 200);
    }

    public function connect_status(WP_REST_Request $request) {
        $session = Massic_Options::get_connect_session();

        return new WP_REST_Response(array(
            'ok' => true,
            'connected' => Massic_Options::get_connection_state() === 'connected',
            'state' => Massic_Options::get_connection_state(),
            'updatedAt' => Massic_Options::get_connection_updated_at(),
            'siteId' => Massic_Options::get_site_id(),
            'siteName' => get_bloginfo('name'),
            'hasPendingConnectSession' => is_array($session),
        ), 200);
    }

    private function merge_settings_collection($input, $key) {
        if (!is_array($input)) {
            return array();
        }

        $output = array();
        $is_list = empty($input) || array_keys($input) === range(0, count($input) - 1);
        if ($is_list) {
            $output = array_merge($output, $this->normalize_collection_items($input));
        }

        if (isset($input[$key]) && is_array($input[$key])) {
            $output = array_merge($output, $this->normalize_collection_items($input[$key]));
        }

        foreach (array('theme', 'custom', 'default') as $scope) {
            if (isset($input[$scope]) && is_array($input[$scope])) {
                $output = array_merge($output, $this->normalize_collection_items($input[$scope]));
            }
        }

        // Deduplicate by slug/color/fontFamily/size key.
        $deduped = array();
        $seen = array();
        foreach ($output as $item) {
            $dedupe_key = md5(wp_json_encode($item));
            if (isset($seen[$dedupe_key])) {
                continue;
            }
            $seen[$dedupe_key] = true;
            $deduped[] = $item;
        }

        return $deduped;
    }

    private function normalize_collection_items($items) {
        if (!is_array($items)) {
            return array();
        }

        $output = array();
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $normalized = array(
                'slug' => sanitize_text_field((string) ($item['slug'] ?? $item['name'] ?? '')),
                'name' => sanitize_text_field((string) ($item['name'] ?? $item['slug'] ?? '')),
            );

            if (isset($item['color'])) {
                $normalized['color'] = sanitize_text_field((string) $item['color']);
            }
            if (isset($item['fontFamily'])) {
                $normalized['fontFamily'] = sanitize_text_field((string) $item['fontFamily']);
            }
            if (isset($item['size'])) {
                $normalized['size'] = sanitize_text_field((string) $item['size']);
            }
            if (isset($item['fontSize'])) {
                $normalized['fontSize'] = sanitize_text_field((string) $item['fontSize']);
            }

            if (
                empty($normalized['slug']) &&
                empty($normalized['name']) &&
                empty($normalized['color'] ?? '') &&
                empty($normalized['fontFamily'] ?? '') &&
                empty($normalized['size'] ?? '') &&
                empty($normalized['fontSize'] ?? '')
            ) {
                continue;
            }

            $output[] = $normalized;
        }

        return $output;
    }

    private function get_hero_image_url($front_page_id, $posts_page_id) {
        $candidate_ids = array();
        if ($front_page_id > 0) {
            $candidate_ids[] = $front_page_id;
        }
        if ($posts_page_id > 0) {
            $candidate_ids[] = $posts_page_id;
        }

        foreach ($candidate_ids as $candidate_id) {
            $thumbnail_id = get_post_thumbnail_id($candidate_id);
            if ($thumbnail_id) {
                $url = wp_get_attachment_image_url($thumbnail_id, 'full');
                if ($url) {
                    return esc_url_raw($url);
                }
            }
        }

        $latest = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => 1,
            'orderby' => 'date',
            'order' => 'DESC',
        ));

        if (is_array($latest) && !empty($latest)) {
            $latest_post = $latest[0];
            $thumbnail_id = get_post_thumbnail_id($latest_post->ID);
            if ($thumbnail_id) {
                $url = wp_get_attachment_image_url($thumbnail_id, 'full');
                if ($url) {
                    return esc_url_raw($url);
                }
            }
        }

        return null;
    }

    public function style_theme(WP_REST_Request $request) {
        $verified = $this->security->verify_signed_request($request, '/wp-json/massic/v1/style/theme');
        if (is_wp_error($verified)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => $verified->get_error_message(),
            ), (int) $verified->get_error_data()['status']);
        }

        $theme = wp_get_theme();
        $is_block_theme = function_exists('wp_is_block_theme') ? wp_is_block_theme() : false;
        $global_settings = function_exists('wp_get_global_settings') ? wp_get_global_settings() : array();

        $palette = array();
        $font_families = array();
        $font_sizes = array();
        $typography = array();

        if (is_array($global_settings)) {
            $palette = $this->merge_settings_collection($global_settings['color']['palette'] ?? array(), 'palette');
            $font_families = $this->merge_settings_collection($global_settings['typography']['fontFamilies'] ?? array(), 'fontFamilies');
            $font_sizes = $this->merge_settings_collection($global_settings['typography']['fontSizes'] ?? array(), 'fontSizes');
            $typography = array(
                'fontSize' => sanitize_text_field((string) ($global_settings['typography']['fontSize'] ?? '')),
                'lineHeight' => sanitize_text_field((string) ($global_settings['typography']['lineHeight'] ?? '')),
            );
        }

        $background_color = get_theme_mod('background_color');
        $background_color = $background_color ? '#' . ltrim((string) $background_color, '#') : '';

        $fallback_styles = array(
            'bodyFontFamily' => sanitize_text_field((string) get_theme_mod('body_font_family', '')),
            'headingFontFamily' => sanitize_text_field((string) get_theme_mod('heading_font_family', '')),
            'baseLineHeight' => sanitize_text_field((string) get_theme_mod('line_height', '')),
            'backgroundColor' => sanitize_text_field((string) $background_color),
            'button' => array(
                'fontFamily' => sanitize_text_field((string) get_theme_mod('button_font_family', '')),
                'fontSize' => sanitize_text_field((string) get_theme_mod('button_font_size', '')),
                'fontWeight' => sanitize_text_field((string) get_theme_mod('button_font_weight', '')),
                'lineHeight' => sanitize_text_field((string) get_theme_mod('button_line_height', '')),
                'textTransform' => sanitize_text_field((string) get_theme_mod('button_text_transform', '')),
            ),
            'headings' => array(
                'h1' => array(
                    'weight' => sanitize_text_field((string) get_theme_mod('h1_font_weight', '')),
                    'lineHeight' => sanitize_text_field((string) get_theme_mod('h1_line_height', '')),
                ),
                'h2' => array(
                    'weight' => sanitize_text_field((string) get_theme_mod('h2_font_weight', '')),
                    'lineHeight' => sanitize_text_field((string) get_theme_mod('h2_line_height', '')),
                ),
                'h3' => array(
                    'weight' => sanitize_text_field((string) get_theme_mod('h3_font_weight', '')),
                    'lineHeight' => sanitize_text_field((string) get_theme_mod('h3_line_height', '')),
                ),
                'h4' => array(
                    'weight' => sanitize_text_field((string) get_theme_mod('h4_font_weight', '')),
                    'lineHeight' => sanitize_text_field((string) get_theme_mod('h4_line_height', '')),
                ),
                'h5' => array(
                    'weight' => sanitize_text_field((string) get_theme_mod('h5_font_weight', '')),
                    'lineHeight' => sanitize_text_field((string) get_theme_mod('h5_line_height', '')),
                ),
                'h6' => array(
                    'weight' => sanitize_text_field((string) get_theme_mod('h6_font_weight', '')),
                    'lineHeight' => sanitize_text_field((string) get_theme_mod('h6_line_height', '')),
                ),
            ),
        );

        $home_url = home_url('/');
        $posts_page_id = absint(get_option('page_for_posts'));
        $posts_page_url = $posts_page_id > 0 ? get_permalink($posts_page_id) : '';

        $sample_post_url = '';
        $latest_post = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => 1,
            'orderby' => 'date',
            'order' => 'DESC',
        ));
        if (is_array($latest_post) && !empty($latest_post)) {
            $sample_post_url = get_permalink($latest_post[0]->ID);
        }

        $custom_logo_url = '';
        $custom_logo_id = absint(get_theme_mod('custom_logo'));
        if ($custom_logo_id > 0) {
            $custom_logo_url = wp_get_attachment_image_url($custom_logo_id, 'full');
        }

        $site_icon_url = get_site_icon_url(512);
        $front_page_id = absint(get_option('page_on_front'));
        $hero_image_url = $this->get_hero_image_url($front_page_id, $posts_page_id);

        return new WP_REST_Response(array(
            'ok' => true,
            'theme' => array(
                'name' => sanitize_text_field((string) $theme->get('Name')),
                'stylesheet' => sanitize_text_field((string) $theme->get_stylesheet()),
                'template' => sanitize_text_field((string) $theme->get_template()),
                'isBlockTheme' => (bool) $is_block_theme,
            ),
            'globalStyles' => array(
                'palette' => $palette,
                'fontFamilies' => $font_families,
                'fontSizes' => $font_sizes,
                'typography' => $typography,
            ),
            'fallbackStyles' => $fallback_styles,
            'urls' => array(
                'homeUrl' => esc_url_raw((string) $home_url),
                'postsPageUrl' => $posts_page_url ? esc_url_raw((string) $posts_page_url) : null,
                'samplePostUrl' => $sample_post_url ? esc_url_raw((string) $sample_post_url) : null,
            ),
            'assets' => array(
                'customLogoUrl' => $custom_logo_url ? esc_url_raw((string) $custom_logo_url) : null,
                'siteIconUrl' => $site_icon_url ? esc_url_raw((string) $site_icon_url) : null,
                'heroImageUrl' => $hero_image_url ? esc_url_raw((string) $hero_image_url) : null,
            ),
        ), 200);
    }

    private function get_wp_error_status(WP_Error $error) {
        $status = 400;
        $error_data = $error->get_error_data();
        if (is_array($error_data) && isset($error_data['status'])) {
            $status = (int) $error_data['status'];
        }

        return $status;
    }

    private function build_wp_error_response(WP_Error $error) {
        $status = $this->get_wp_error_status($error);
        $details = $error->get_error_data();
        if (!is_array($details)) {
            $details = array(
                'status' => $status,
            );
        }

        return new WP_REST_Response(array(
            'ok' => false,
            'code' => $error->get_error_code(),
            'message' => $error->get_error_message(),
            'details' => $details,
        ), $status);
    }

    public function content_upsert(WP_REST_Request $request) {
        $verified = $this->security->verify_signed_request($request, '/wp-json/massic/v1/content/upsert');
        if (is_wp_error($verified)) {
            return $this->build_wp_error_response($verified);
        }

        $payload = $request->get_json_params();
        if (!is_array($payload)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'Invalid JSON payload',
            ), 400);
        }

        $result = $this->content->upsert($payload);
        if (is_wp_error($result)) {
            return $this->build_wp_error_response($result);
        }

        return new WP_REST_Response($result, 200);
    }

    public function content_slug_check(WP_REST_Request $request) {
        $verified = $this->security->verify_signed_request($request, '/wp-json/massic/v1/content/slug-check');
        if (is_wp_error($verified)) {
            return $this->build_wp_error_response($verified);
        }

        $payload = $request->get_json_params();
        if (!is_array($payload)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'code' => 'massic_invalid_payload',
                'message' => 'Invalid JSON payload',
                'details' => array(
                    'status' => 400,
                ),
            ), 400);
        }

        $result = $this->content->slug_check($payload);
        if (is_wp_error($result)) {
            return $this->build_wp_error_response($result);
        }

        return new WP_REST_Response($result, 200);
    }

    public function content_unpublish(WP_REST_Request $request) {
        $verified = $this->security->verify_signed_request($request, '/wp-json/massic/v1/content/unpublish');
        if (is_wp_error($verified)) {
            return $this->build_wp_error_response($verified);
        }

        $payload = $request->get_json_params();
        if (!is_array($payload)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'Invalid JSON payload',
            ), 400);
        }

        $result = $this->content->unpublish($payload);
        if (is_wp_error($result)) {
            return $this->build_wp_error_response($result);
        }

        return new WP_REST_Response($result, 200);
    }

    public function content_preview_link(WP_REST_Request $request) {
        $verified = $this->security->verify_signed_request($request, '/wp-json/massic/v1/content/preview-link');
        if (is_wp_error($verified)) {
            return $this->build_wp_error_response($verified);
        }

        $wp_id = absint($request->get_param('wpId'));
        if ($wp_id <= 0) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'wpId is required',
            ), 400);
        }

        $post = get_post($wp_id);
        if (!$post || !in_array($post->post_type, array('post', 'page'), true)) {
            return new WP_REST_Response(array(
                'ok' => false,
                'message' => 'Invalid wpId',
            ), 404);
        }

        $expires_in = absint($request->get_param('expiresIn'));
        if ($expires_in < 60 || $expires_in > 3600) {
            $expires_in = 600;
        }

        $token = wp_generate_password(32, false, false);
        set_transient('massic_preview_token_' . md5($token), array(
            'post_id' => $wp_id,
        ), $expires_in);

        $preview_url = add_query_arg(array(
            'p' => $wp_id,
            'massic_preview' => '1',
            'massic_preview_token' => $token,
        ), home_url('/'));

        return new WP_REST_Response(array(
            'ok' => true,
            'wpId' => $wp_id,
            'previewUrl' => esc_url_raw($preview_url),
            'expiresAt' => gmdate('c', time() + $expires_in),
        ), 200);
    }
}
