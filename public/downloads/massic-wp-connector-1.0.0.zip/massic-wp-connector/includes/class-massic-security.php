<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Security {
    const NONCE_TRANSIENT_PREFIX = 'massic_nonce_';

    public function verify_signed_request(WP_REST_Request $request, $path) {
        $site_id = sanitize_text_field((string) $request->get_header('X-Massic-SiteId'));
        $timestamp = sanitize_text_field((string) $request->get_header('X-Massic-Timestamp'));
        $nonce = sanitize_text_field((string) $request->get_header('X-Massic-Nonce'));
        $signature = sanitize_text_field((string) $request->get_header('X-Massic-Signature'));

        if (!$site_id || !$timestamp || !$nonce || !$signature) {
            return new WP_Error('massic_missing_headers', 'Missing Massic auth headers', array('status' => 401));
        }

        if ($site_id !== Massic_Options::get_site_id()) {
            return new WP_Error('massic_invalid_site', 'Invalid site id', array('status' => 401));
        }

        if (!ctype_digit($timestamp)) {
            return new WP_Error('massic_invalid_timestamp', 'Invalid timestamp', array('status' => 401));
        }

        if (!preg_match('/^[a-f0-9]{16,64}$/', strtolower($nonce))) {
            return new WP_Error('massic_invalid_nonce', 'Invalid nonce', array('status' => 401));
        }

        $ttl = Massic_Options::get_nonce_ttl();
        $now = time();
        $request_ts = intval($timestamp);
        if (abs($now - $request_ts) > $ttl) {
            return new WP_Error('massic_stale_request', 'Request timestamp is outside allowed window', array('status' => 401));
        }

        $nonce_key = self::NONCE_TRANSIENT_PREFIX . md5($nonce);
        if (get_transient($nonce_key)) {
            return new WP_Error('massic_replay_nonce', 'Nonce already used', array('status' => 401));
        }

        $secret = Massic_Options::get_client_secret();
        if (!$secret) {
            return new WP_Error('massic_not_configured', 'Plugin client secret is not configured', array('status' => 400));
        }

        $method = strtoupper($request->get_method());
        $body_raw = (string) $request->get_body();
        $body_hash = hash('sha256', $body_raw);
        $canonical = $method . "\n" . $path . "\n" . $timestamp . "\n" . $nonce . "\n" . $body_hash;
        $expected = hash_hmac('sha256', $canonical, $secret);

        if (!hash_equals($expected, strtolower($signature))) {
            return new WP_Error('massic_bad_signature', 'Invalid signature', array('status' => 401));
        }

        set_transient($nonce_key, 1, $ttl);
        Massic_Options::set_last_nonce_cache($nonce);

        return true;
    }
}
