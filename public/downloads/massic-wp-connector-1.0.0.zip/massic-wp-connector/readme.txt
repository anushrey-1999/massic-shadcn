=== Massic WP Connector ===
Contributors: massic
Tags: cms, content, publishing, api, seo
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Secure WordPress connector for Massic pairing, publishing, and SEO head metadata.

== Description ==
Massic WP Connector links your WordPress site to Massic so authorized users can publish and unpublish WordPress posts/pages from Massic with signed requests.

Key features:

* One-click connect flow from WP Admin with secure pairing.
* Signed REST endpoints for upsert, unpublish, and preview link creation.
* Draft and publish support for posts and pages.
* Structured SEO head payload storage and rendering on singular content.
* Page-local Massic CSS embedding for Massic-generated content only.
* Best-effort lifecycle sync on plugin deactivate/uninstall.

Security model:

* Requests are verified with HMAC signatures, nonce, and timestamp checks.
* Site-scoped identifiers and secrets are required for privileged operations.
* Content writes are constrained to `post` and `page` post types.

== External services ==
This plugin connects to external Massic services to complete pairing and content publishing workflows.

1. Massic Backend API (`MASSIC_BACKEND_BASE`, for example `https://seedmain.seedinternaldev.xyz`)
* What it is used for: pairing lifecycle sync and secure connector operations.
* What data is sent: site ID, signed request metadata, connection lifecycle state, and connector status details.
* When data is sent: during connect/disconnect, plugin lifecycle events, and connector admin actions.

2. Massic App (`MASSIC_APP_BASE`, for example `https://app.massic.io`)
* What it is used for: one-click approval flow initiated from WP Admin.
* What data is sent: site ID, state token, and connect-session identifiers needed for approval.
* When data is sent: when an admin starts the recommended connect flow.

Publisher links:
* Terms: https://massic.io/terms-conditions
* Privacy policy: https://massic.io/privacy-policy

== Installation ==
1. Upload the `massic-wp-connector` folder to `/wp-content/plugins/`.
2. Activate the plugin in WP Admin.
3. Go to Settings > Massic Connector.
4. Configure service endpoints (if different from defaults):
   - `wp-config.php`: `define('MASSIC_BACKEND_BASE', 'https://your-backend.example');`
   - `wp-config.php`: `define('MASSIC_APP_BASE', 'https://your-app.example');`
5. Click `Connect to Massic (Recommended)` and complete approval.
6. Verify the connector shows `Connected`.

Manual fallback:
* Expand `Manual setup (Advanced)` and use Site ID / Pairing Code / Client Secret.

== Frequently Asked Questions ==
= Does this plugin affect non-Massic pages? =
No. The plugin does not globally enqueue front-end styles for the site. Massic CSS is embedded only in Massic-published content.

= What happens if I deactivate or remove the plugin? =
Previously published content remains in WordPress. Content and embedded page CSS stay in the post content.

= Which post types are supported? =
The connector only writes to standard WordPress `post` and `page` types.

= Can I keep using manual WordPress editing? =
Yes. Standard WordPress editing remains available. The connector only handles signed Massic publish actions.

== Screenshots ==
1. Settings > Massic Connector screen with connect controls.
2. Connected state with Site ID and connection status.
3. Manual setup section with pairing details.

== Changelog ==
= 1.0.0 =
* Initial public release.
* Secure connect/disconnect flow with signed requests.
* Signed content upsert/unpublish/preview-link endpoints.
* Structured SEO head metadata rendering.
* Page-local Massic CSS support for Massic-generated content.

== Upgrade Notice ==
= 1.0.0 =
Initial public release.
