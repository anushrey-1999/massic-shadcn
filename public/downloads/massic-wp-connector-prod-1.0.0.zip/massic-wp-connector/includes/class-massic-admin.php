<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Admin {
    public function init() {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_post_massic_oauth_start', array($this, 'handle_oauth_start'));
    }

    public function register_menu() {
        add_options_page(
            __('Massic Integration', 'massic-wp-connector'),
            __('Massic Integration', 'massic-wp-connector'),
            'manage_options',
            'massic-wp-connector',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting('massic_connector_group', Massic_Options::OPTION_SITE_ID, array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));

        register_setting('massic_connector_group', Massic_Options::OPTION_PAIRING_CODE, array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));

        register_setting('massic_connector_group', Massic_Options::OPTION_CLIENT_SECRET, array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));

        register_setting('massic_connector_group', Massic_Options::OPTION_NONCE_TTL, array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 300,
        ));
    }

    public function handle_oauth_start() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'massic-wp-connector'));
        }

        check_admin_referer('massic_oauth_start');

        $backend_base = Massic_Options::get_backend_base();
        if (!$backend_base) {
            $this->redirect_with_notice(__('Connection is not available right now. Please contact support.', 'massic-wp-connector'), 'error');
        }

        $backend_host = wp_parse_url($backend_base, PHP_URL_HOST);
        if (!$this->is_allowed_backend_host($backend_host)) {
            $this->redirect_with_notice(__('Massic backend host is not allowed for public connector builds. Please contact support.', 'massic-wp-connector'), 'error');
        }

        $site_id = Massic_Options::get_site_id();
        if (!$site_id) {
            $this->redirect_with_notice(__('Could not start connection. Please refresh and try again.', 'massic-wp-connector'), 'error');
        }

        if (!Massic_Options::get_client_secret()) {
            Massic_Options::rotate_client_secret();
        }

        $state = wp_generate_password(40, false, false);
        $finalize_token = wp_generate_password(56, false, false);
        $return_url = admin_url('admin.php?page=massic-wp-connector');

        Massic_Options::create_connect_session(
            $state,
            $finalize_token,
            $return_url,
            get_current_user_id()
        );

        $start_url = rtrim($backend_base, '/') . '/api/cms/wordpress/oauth/start';
        $redirect_url = add_query_arg(array(
            'siteUrl' => site_url(),
            'siteId' => $site_id,
            'state' => $state,
            'finalizeToken' => $finalize_token,
            'returnUrl' => $return_url,
        ), $start_url);

        add_filter('allowed_redirect_hosts', function($hosts) use ($backend_host) {
            $hosts[] = $backend_host;
            return array_values(array_unique(array_filter($hosts)));
        });

        wp_safe_redirect($redirect_url);
        exit;
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $connection_state = Massic_Options::get_connection_state();
        $connection_updated_at = Massic_Options::get_connection_updated_at();
        $connection_updated_at_readable = $this->format_datetime_for_admin($connection_updated_at);

        $notice_message = sanitize_text_field((string) ($_GET['massic_notice'] ?? ''));
        $notice_type = sanitize_text_field((string) ($_GET['massic_notice_type'] ?? 'success'));
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Massic Integration', 'massic-wp-connector'); ?></h1>

            <?php if ($notice_message) : ?>
                <div class="notice <?php echo esc_attr($notice_type === 'error' ? 'notice-error' : 'notice-success'); ?> is-dismissible">
                    <p><?php echo esc_html($notice_message); ?></p>
                </div>
            <?php endif; ?>

            <div style="margin: 12px 0 18px; padding: 10px 12px; border: 1px solid #dcdcde; border-radius: 6px; background: #fff;">
                <p style="margin:0 0 4px;">
                    <strong><?php esc_html_e('Service disclosure:', 'massic-wp-connector'); ?></strong>
                    <?php esc_html_e('This plugin requires a Massic account. Connecting sends site and content data to Massic so Massic can publish, preview, unpublish, and manage authorized WordPress content.', 'massic-wp-connector'); ?>
                </p>
                <p style="margin:0; color:#646970;">
                    <a href="https://massic.io/terms" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Massic Terms', 'massic-wp-connector'); ?></a>
                    &nbsp;|&nbsp;
                    <a href="https://massic.io/privacy" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Massic Privacy Policy', 'massic-wp-connector'); ?></a>
                </p>
            </div>

            <div style="margin: 12px 0 18px; padding: 10px 12px; border: 1px solid #dcdcde; border-radius: 6px; background: #fff;">
                <p style="margin:0 0 4px;"><strong><?php esc_html_e('Connection Status:', 'massic-wp-connector'); ?></strong>
                    <?php if ($connection_state === 'connected') : ?>
                        <span style="color:#008a20;"><?php esc_html_e('Connected', 'massic-wp-connector'); ?></span>
                    <?php else : ?>
                        <span style="color:#646970;"><?php esc_html_e('Disconnected', 'massic-wp-connector'); ?></span>
                    <?php endif; ?>
                </p>
                <?php if (!empty($connection_updated_at)) : ?>
                    <p style="margin:0; color:#646970;">
                        <strong><?php esc_html_e('Last Updated:', 'massic-wp-connector'); ?></strong>
                        <span title="<?php echo esc_attr($connection_updated_at); ?>">
                            <?php echo esc_html($connection_updated_at_readable); ?>
                        </span>
                    </p>
                <?php endif; ?>
            </div>

            <h2><?php esc_html_e('Connect', 'massic-wp-connector'); ?></h2>
            <?php if ($connection_state === 'connected') : ?>
                <div style="margin-bottom:18px; padding:10px 12px; border:1px solid #dcdcde; border-radius:6px; background:#f6f7f7;">
                    <p style="margin:0; color:#1d2327;"><strong><?php esc_html_e('Already connected.', 'massic-wp-connector'); ?></strong> <?php esc_html_e('No further action is required.', 'massic-wp-connector'); ?></p>
                </div>
            <?php else : ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:18px;">
                    <input type="hidden" name="action" value="massic_oauth_start" />
                    <?php wp_nonce_field('massic_oauth_start'); ?>
                    <button type="submit" class="button button-primary">
                        <?php esc_html_e('Connect to Massic (Recommended)', 'massic-wp-connector'); ?>
                    </button>
                </form>
            <?php endif; ?>

            <details>
                <summary style="cursor:pointer;"><strong><?php esc_html_e('Manual Setup (Advanced)', 'massic-wp-connector'); ?></strong></summary>
                <form method="post" action="options.php">
                    <?php settings_fields('massic_connector_group'); ?>
                    <?php do_settings_sections('massic_connector_group'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>"><?php esc_html_e('Site ID', 'massic-wp-connector'); ?></label></th>
                            <td>
                                <input
                                    id="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>"
                                    name="<?php echo esc_attr(Massic_Options::OPTION_SITE_ID); ?>"
                                    type="text"
                                    class="regular-text"
                                    value="<?php echo esc_attr(Massic_Options::get_site_id()); ?>"
                                />
                                <button
                                    type="button"
                                    class="button button-secondary"
                                    style="margin-left:8px;"
                                    onclick="massicCopyValue('<?php echo esc_js(Massic_Options::OPTION_SITE_ID); ?>', this)"
                                >
                                    <?php esc_html_e('Copy', 'massic-wp-connector'); ?>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>"><?php esc_html_e('Pairing Code', 'massic-wp-connector'); ?></label></th>
                            <td>
                                <input
                                    id="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>"
                                    name="<?php echo esc_attr(Massic_Options::OPTION_PAIRING_CODE); ?>"
                                    type="text"
                                    class="regular-text"
                                    value="<?php echo esc_attr(Massic_Options::get_pairing_code()); ?>"
                                />
                                <button
                                    type="button"
                                    class="button button-secondary"
                                    style="margin-left:8px;"
                                    onclick="massicCopyValue('<?php echo esc_js(Massic_Options::OPTION_PAIRING_CODE); ?>', this)"
                                >
                                    <?php esc_html_e('Copy', 'massic-wp-connector'); ?>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>"><?php esc_html_e('Client Secret', 'massic-wp-connector'); ?></label></th>
                            <td>
                                <input
                                    id="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>"
                                    name="<?php echo esc_attr(Massic_Options::OPTION_CLIENT_SECRET); ?>"
                                    type="password"
                                    class="regular-text"
                                    value="<?php echo esc_attr(Massic_Options::get_client_secret()); ?>"
                                    autocomplete="new-password"
                                />
                                <button
                                    type="button"
                                    class="button button-secondary"
                                    style="margin-left:8px;"
                                    onclick="massicCopyValue('<?php echo esc_js(Massic_Options::OPTION_CLIENT_SECRET); ?>', this)"
                                >
                                    <?php esc_html_e('Copy', 'massic-wp-connector'); ?>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="<?php echo esc_attr(Massic_Options::OPTION_NONCE_TTL); ?>"><?php esc_html_e('Nonce TTL (seconds)', 'massic-wp-connector'); ?></label></th>
                            <td><input name="<?php echo esc_attr(Massic_Options::OPTION_NONCE_TTL); ?>" type="number" min="60" max="3600" class="small-text" value="<?php echo esc_attr(Massic_Options::get_nonce_ttl()); ?>" /></td>
                        </tr>
                    </table>
                    <?php submit_button(__('Save Manual Settings', 'massic-wp-connector')); ?>
                </form>
            </details>
        </div>
        <script>
                function massicCopyValue(inputId, buttonEl) {
                    var input = document.getElementById(inputId);
                    if (!input) return;

                    var value = input.value || '';
                    if (!value) return;

                    function markCopied() {
                        var original = buttonEl.textContent;
                        buttonEl.textContent = <?php echo wp_json_encode(__('Copied', 'massic-wp-connector')); ?>;
                        setTimeout(function () {
                            buttonEl.textContent = original;
                        }, 1200);
                    }

                    function fallbackCopy() {
                        var originalType = input.type;
                        if (originalType === 'password') {
                            input.type = 'text';
                        }
                        input.select();
                        document.execCommand('copy');
                        if (originalType === 'password') {
                            input.type = originalType;
                        }
                        markCopied();
                    }

                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(value).then(markCopied).catch(fallbackCopy);
                        return;
                    }

                    fallbackCopy();
                }
        </script>
        <?php
    }

    private function format_datetime_for_admin($value) {
        $raw = trim((string) $value);
        if (!$raw) {
            return '';
        }

        $timestamp = strtotime($raw);
        if (!$timestamp) {
            return $raw;
        }

        $absolute = wp_date('M j, Y g:i A T', $timestamp);
        $now = time();
        $distance = human_time_diff($timestamp, $now);
        $relative = $timestamp <= $now ? ($distance . ' ago') : ('in ' . $distance);

        return $absolute . ' (' . $relative . ')';
    }

    private function is_allowed_backend_host($host) {
        $host = strtolower(sanitize_text_field((string) $host));
        if (!$host) {
            return false;
        }

        $allowed_hosts = array('agency.massic.io');
        $allowed_hosts = apply_filters('massic_wp_connector_allowed_backend_hosts', $allowed_hosts);
        $allowed_hosts = array_map('strtolower', array_map('sanitize_text_field', (array) $allowed_hosts));

        return in_array($host, $allowed_hosts, true);
    }

    private function redirect_with_notice($message, $type = 'success') {
        $redirect_url = add_query_arg(array(
            'page' => 'massic-wp-connector',
            'massic_notice' => (string) $message,
            'massic_notice_type' => $type === 'error' ? 'error' : 'success',
        ), admin_url('options-general.php'));

        wp_safe_redirect($redirect_url);
        exit;
    }
}
