<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Head {
    const META_HEAD_PAYLOAD = '_massic_head_payload';
    const META_SEO_TITLE = '_massic_meta_title';
    const META_SEO_DESCRIPTION = '_massic_meta_description';
    const META_FEATURED_IMAGE_ATTACHMENT_ID = '_massic_featured_image_attachment_id';
    const META_FEATURED_IMAGE_WP_URL = '_massic_featured_image_wp_url';
    const META_FEATURED_IMAGE_ALT_TEXT = '_massic_featured_image_alt_text';
    const META_FEATURED_IMAGE_WIDTH = '_massic_featured_image_width';
    const META_FEATURED_IMAGE_HEIGHT = '_massic_featured_image_height';
    const META_FEATURED_IMAGE_MIME_TYPE = '_massic_featured_image_mime_type';

    public function init() {
        add_action('wp_head', array($this, 'render_head'), 5);
        add_filter('pre_get_document_title', array($this, 'filter_document_title'), 20);
    }

    private function output_meta_name($name, $content) {
        if (!$content) {
            return;
        }
        echo '<meta name="' . esc_attr($name) . '" content="' . esc_attr($content) . '" />' . "\n";
    }

    private function output_meta_property($property, $content) {
        if (!$content) {
            return;
        }
        echo '<meta property="' . esc_attr($property) . '" content="' . esc_attr($content) . '" />' . "\n";
    }

    private function output_json_ld($data) {
        if (empty($data) || !is_array($data)) {
            return;
        }

        echo '<script type="application/ld+json">' . wp_json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }

    private function get_current_post_id() {
        if (!is_singular()) {
            return 0;
        }

        $post_id = get_queried_object_id();
        return $post_id ? (int) $post_id : 0;
    }

    private function get_head_payload($post_id) {
        if (!$post_id) {
            return array();
        }

        $raw = get_post_meta($post_id, self::META_HEAD_PAYLOAD, true);
        if (!$raw) {
            return array();
        }

        $head = json_decode($raw, true);
        return is_array($head) ? $head : array();
    }

    private function get_head_string($head, $key) {
        if (!is_array($head) || !isset($head[$key]) || !is_scalar($head[$key])) {
            return '';
        }

        return trim((string) $head[$key]);
    }

    private function get_post_meta_string($post_id, $meta_key) {
        if (!$post_id) {
            return '';
        }

        $value = get_post_meta($post_id, $meta_key, true);
        return is_scalar($value) ? trim((string) $value) : '';
    }

    private function get_post_meta_positive_int($post_id, $meta_key) {
        $value = $this->get_post_meta_string($post_id, $meta_key);
        $number = absint($value);
        return $number > 0 ? $number : null;
    }

    private function is_managed_image_meta_tag($name, $property) {
        $managed_names = array('twitter:image', 'twitter:image:alt');
        $managed_properties = array(
            'og:image',
            'og:image:secure_url',
            'og:image:alt',
            'og:image:width',
            'og:image:height',
            'og:image:type',
        );

        return in_array(strtolower((string) $name), $managed_names, true)
            || in_array(strtolower((string) $property), $managed_properties, true);
    }

    private function get_excerpt_fallback($post_id) {
        $excerpt = get_the_excerpt($post_id);
        return is_string($excerpt) ? trim(wp_strip_all_tags($excerpt)) : '';
    }

    private function resolve_featured_image($post_id) {
        $attachment_id = absint(get_post_thumbnail_id($post_id));
        if ($attachment_id <= 0) {
            $attachment_id = absint(get_post_meta($post_id, self::META_FEATURED_IMAGE_ATTACHMENT_ID, true));
        }

        $image = array(
            'url' => '',
            'alt' => '',
            'width' => null,
            'height' => null,
            'mimeType' => '',
        );

        if ($attachment_id > 0 && get_post($attachment_id)) {
            $image_src = wp_get_attachment_image_src($attachment_id, 'full');
            if (is_array($image_src)) {
                $image['url'] = !empty($image_src[0]) ? esc_url_raw((string) $image_src[0]) : '';
                $image['width'] = !empty($image_src[1]) ? absint($image_src[1]) : null;
                $image['height'] = !empty($image_src[2]) ? absint($image_src[2]) : null;
            }

            if (!$image['url']) {
                $attachment_url = wp_get_attachment_url($attachment_id);
                $image['url'] = $attachment_url ? esc_url_raw((string) $attachment_url) : '';
            }

            $image['alt'] = sanitize_text_field((string) get_post_meta($attachment_id, '_wp_attachment_image_alt', true));
            $image['mimeType'] = sanitize_text_field((string) get_post_mime_type($attachment_id));
        }

        if (!$image['url']) {
            $image['url'] = esc_url_raw($this->get_post_meta_string($post_id, self::META_FEATURED_IMAGE_WP_URL));
        }
        if ($image['alt'] === '') {
            $image['alt'] = $this->get_post_meta_string($post_id, self::META_FEATURED_IMAGE_ALT_TEXT);
        }
        if (!$image['width']) {
            $image['width'] = $this->get_post_meta_positive_int($post_id, self::META_FEATURED_IMAGE_WIDTH);
        }
        if (!$image['height']) {
            $image['height'] = $this->get_post_meta_positive_int($post_id, self::META_FEATURED_IMAGE_HEIGHT);
        }
        if ($image['mimeType'] === '') {
            $image['mimeType'] = $this->get_post_meta_string($post_id, self::META_FEATURED_IMAGE_MIME_TYPE);
        }

        return $image['url'] ? $image : null;
    }

    public function filter_document_title($title) {
        $post_id = $this->get_current_post_id();
        if (!$post_id || get_post_type($post_id) !== 'post') {
            return $title;
        }

        $head = $this->get_head_payload($post_id);
        $seo_title = $this->get_head_string($head, 'seoTitle');
        if ($seo_title === '') {
            $seo_title = $this->get_post_meta_string($post_id, self::META_SEO_TITLE);
        }

        return $seo_title !== '' ? $seo_title : $title;
    }

    public function render_head() {
        $post_id = $this->get_current_post_id();
        if (!$post_id) {
            return;
        }

        $is_blog_post = get_post_type($post_id) === 'post';
        $head = $this->get_head_payload($post_id);
        $featured_image = $this->resolve_featured_image($post_id);
        $seo_title = $is_blog_post ? $this->get_head_string($head, 'seoTitle') : '';
        $meta_description = $this->get_head_string($head, 'metaDescription');
        $og_title = $this->get_head_string($head, 'ogTitle');
        $og_description = $this->get_head_string($head, 'ogDescription');
        $twitter_title = $this->get_head_string($head, 'twitterTitle');
        $twitter_description = $this->get_head_string($head, 'twitterDescription');

        if ($is_blog_post && $seo_title === '') {
            $seo_title = $this->get_post_meta_string($post_id, self::META_SEO_TITLE);
        }
        if ($seo_title === '') {
            $seo_title = trim(wp_strip_all_tags(get_the_title($post_id)));
        }
        if ($is_blog_post && $meta_description === '') {
            $meta_description = $this->get_post_meta_string($post_id, self::META_SEO_DESCRIPTION);
        }
        if ($meta_description === '') {
            $meta_description = $this->get_excerpt_fallback($post_id);
        }
        if ($is_blog_post && $og_title === '') {
            $og_title = $seo_title;
        }
        if ($is_blog_post && $og_description === '') {
            $og_description = $meta_description;
        }
        if ($is_blog_post && $twitter_title === '') {
            $twitter_title = $seo_title;
        }
        if ($is_blog_post && $twitter_description === '') {
            $twitter_description = $meta_description;
        }

        if ($og_title === '') {
            $og_title = $seo_title;
        }
        if ($og_description === '') {
            $og_description = $meta_description;
        }
        if ($twitter_title === '') {
            $twitter_title = $seo_title;
        }
        if ($twitter_description === '') {
            $twitter_description = $meta_description;
        }

        $permalink = get_permalink($post_id);
        $og_type = $is_blog_post ? 'article' : 'website';

        if (!empty($head['canonicalUrl'])) {
            echo '<link rel="canonical" href="' . esc_url($head['canonicalUrl']) . '" />' . "\n";
        }

        $this->output_meta_name('description', $meta_description);
        $this->output_meta_name('robots', isset($head['robots']) ? $head['robots'] : '');

        $this->output_meta_property('og:title', $og_title);
        $this->output_meta_property('og:description', $og_description);
        $this->output_meta_property('og:type', $og_type);
        $this->output_meta_property('og:url', $permalink);

        if ($featured_image) {
            $this->output_meta_property('og:image', $featured_image['url']);
            $this->output_meta_property('og:image:secure_url', $featured_image['url']);
            $this->output_meta_property('og:image:alt', $featured_image['alt']);
            $this->output_meta_property('og:image:width', $featured_image['width']);
            $this->output_meta_property('og:image:height', $featured_image['height']);
            $this->output_meta_property('og:image:type', $featured_image['mimeType']);
        }

        $twitter_card = isset($head['twitterCard']) ? $head['twitterCard'] : '';
        if (!$twitter_card && $featured_image) {
            $twitter_card = 'summary_large_image';
        }

        $this->output_meta_name('twitter:card', $twitter_card);
        $this->output_meta_name('twitter:title', $twitter_title);
        $this->output_meta_name('twitter:description', $twitter_description);
        if ($featured_image) {
            $this->output_meta_name('twitter:image', $featured_image['url']);
            $this->output_meta_name('twitter:image:alt', $featured_image['alt']);
        }

        if ($is_blog_post) {
            $published_time = get_the_date('c', $post_id);
            $modified_time = get_the_modified_date('c', $post_id);

            $this->output_meta_property('article:published_time', $published_time);
            $this->output_meta_property('article:modified_time', $modified_time);

            $json_ld = array(
                '@context' => 'https://schema.org',
                '@type' => 'BlogPosting',
                'headline' => $seo_title,
                'description' => $meta_description,
                'datePublished' => $published_time,
                'dateModified' => $modified_time,
                'mainEntityOfPage' => array(
                    '@type' => 'WebPage',
                    '@id' => $permalink,
                ),
            );

            if ($featured_image) {
                $json_ld['image'] = array_filter(array(
                    '@type' => 'ImageObject',
                    'url' => $featured_image['url'],
                    'width' => $featured_image['width'],
                    'height' => $featured_image['height'],
                    'caption' => $featured_image['alt'],
                ));
            }

            $this->output_json_ld(array_filter($json_ld));
        }

        if (!empty($head['alternates']) && is_array($head['alternates'])) {
            foreach ($head['alternates'] as $alt) {
                if (!is_array($alt)) {
                    continue;
                }
                $href = !empty($alt['href']) ? (string) $alt['href'] : '';
                $hreflang = !empty($alt['hreflang']) ? sanitize_text_field((string) $alt['hreflang']) : '';
                if ($href && $hreflang) {
                    echo '<link rel="alternate" href="' . esc_url($href) . '" hreflang="' . esc_attr($hreflang) . '" />' . "\n";
                }
            }
        }

        if (!empty($head['metaTags']) && is_array($head['metaTags'])) {
            foreach ($head['metaTags'] as $meta) {
                if (!is_array($meta)) {
                    continue;
                }
                $name = !empty($meta['name']) ? sanitize_text_field($meta['name']) : '';
                $property = !empty($meta['property']) ? sanitize_text_field($meta['property']) : '';
                $content = !empty($meta['content']) ? sanitize_text_field($meta['content']) : '';
                if ($this->is_managed_image_meta_tag($name, $property)) {
                    continue;
                }
                if ($name && $content) {
                    $this->output_meta_name($name, $content);
                } elseif ($property && $content) {
                    $this->output_meta_property($property, $content);
                }
            }
        }

        if (!empty($head['linkTags']) && is_array($head['linkTags'])) {
            foreach ($head['linkTags'] as $link) {
                if (!is_array($link)) {
                    continue;
                }
                $rel = !empty($link['rel']) ? sanitize_text_field((string) $link['rel']) : '';
                $href = !empty($link['href']) ? (string) $link['href'] : '';
                $type = !empty($link['type']) ? sanitize_text_field((string) $link['type']) : '';
                $sizes = !empty($link['sizes']) ? sanitize_text_field((string) $link['sizes']) : '';

                if (!$rel || !$href) {
                    continue;
                }

                echo '<link rel="' . esc_attr($rel) . '" href="' . esc_url($href) . '"';
                if ($type) {
                    echo ' type="' . esc_attr($type) . '"';
                }
                if ($sizes) {
                    echo ' sizes="' . esc_attr($sizes) . '"';
                }
                echo ' />' . "\n";
            }
        }
    }
}
