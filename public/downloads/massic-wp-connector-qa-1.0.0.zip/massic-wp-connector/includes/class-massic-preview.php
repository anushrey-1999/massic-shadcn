<?php

if (!defined('ABSPATH')) {
    exit;
}

class Massic_Preview {
    const QUERY_PREVIEW = 'massic_preview';
    const QUERY_TOKEN = 'massic_preview_token';

    public function init() {
        add_filter('query_vars', array($this, 'register_query_vars'));
        add_action('pre_get_posts', array($this, 'allow_draft_query')); 
        add_action('template_redirect', array($this, 'redirect_legacy_page_preview_url'), 0);
        add_action('template_redirect', array($this, 'block_invalid_preview')); 
        add_filter('template_include', array($this, 'use_selected_page_template'), 99);
    }

    public function register_query_vars($vars) {
        $vars[] = self::QUERY_PREVIEW;
        $vars[] = self::QUERY_TOKEN;
        return $vars;
    }

    private function get_validated_post_id() {
        $preview = get_query_var(self::QUERY_PREVIEW);
        $token = sanitize_text_field((string) get_query_var(self::QUERY_TOKEN));
        $post_id = absint(get_query_var('p'));
        if ($post_id <= 0) {
            $post_id = absint(get_query_var('page_id'));
        }

        if (!$preview || !$token || $post_id <= 0) {
            return 0;
        }

        $payload = get_transient('massic_preview_token_' . md5($token));
        if (!is_array($payload) || empty($payload['post_id'])) {
            return 0;
        }

        if (intval($payload['post_id']) !== $post_id) {
            return 0;
        }

        return $post_id;
    }

    public function allow_draft_query($query) {
        if (is_admin() || !$query->is_main_query()) {
            return;
        }

        $post_id = $this->get_validated_post_id();
        if (!$post_id) {
            return;
        }

        $post = get_post($post_id);
        if ($post && $post->post_type === 'page') {
            $query->set('p', 0);
            $query->set('page_id', $post_id);
            $query->set('post_type', 'page');
        } else {
            $query->set('p', $post_id);
            $query->set('post_type', 'post');
        }
        $query->set('post_status', array('publish', 'draft', 'pending', 'private', 'future'));
    }

    public function redirect_legacy_page_preview_url() {
        $preview = get_query_var(self::QUERY_PREVIEW);
        if (!$preview || absint(get_query_var('page_id')) > 0 || absint(get_query_var('p')) <= 0) {
            return;
        }

        $post_id = $this->get_validated_post_id();
        if (!$post_id) {
            return;
        }

        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'page') {
            return;
        }

        $redirect_url = add_query_arg(array(
            'page_id' => $post_id,
            self::QUERY_PREVIEW => '1',
            self::QUERY_TOKEN => sanitize_text_field((string) get_query_var(self::QUERY_TOKEN)),
        ), home_url('/'));

        wp_safe_redirect(esc_url_raw($redirect_url));
        exit;
    }

    public function block_invalid_preview() {
        $preview = get_query_var(self::QUERY_PREVIEW);
        if (!$preview) {
            return;
        }

        $post_id = $this->get_validated_post_id();
        if (!$post_id) {
            status_header(403);
            nocache_headers();
            wp_die(esc_html__('Invalid or expired preview token', 'massic-integration'));
        }
    }

    public function use_selected_page_template($template) {
        $preview = get_query_var(self::QUERY_PREVIEW);
        if (!$preview) {
            return $template;
        }

        $post_id = $this->get_validated_post_id();
        if (!$post_id) {
            return $template;
        }

        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'page') {
            return $template;
        }

        $template_slug = get_page_template_slug($post_id);
        if (!$template_slug) {
            return $template;
        }

        $located_template = locate_template($template_slug);
        return $located_template ? $located_template : $template;
    }
}
