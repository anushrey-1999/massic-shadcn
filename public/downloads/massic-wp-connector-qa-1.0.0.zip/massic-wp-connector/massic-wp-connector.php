<?php
/**
 * Plugin Name: Massic WP Connector
 * Plugin URI: https://massic.io
 * Description: Connects WordPress with Massic backend for secure content upsert and structured head tag rendering.
 * Version: 1.0.0
 * Author: Massic
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: massic-wp-connector
 */

if (!defined('ABSPATH')) {
    exit;
}

define('MASSIC_WP_CONNECTOR_VERSION', '1.0.0');
define('MASSIC_WP_CONNECTOR_PATH', plugin_dir_path(__FILE__));
define('MASSIC_WP_CONNECTOR_URL', plugin_dir_url(__FILE__));

if (!defined('MASSIC_BACKEND_BASE')) {
    define('MASSIC_BACKEND_BASE', 'https://seedmain.seedinternaldev.xyz');
}

if (!defined('MASSIC_APP_BASE')) {
    define('MASSIC_APP_BASE', 'https://seedinternaldev.xyz');
}

require_once MASSIC_WP_CONNECTOR_PATH . 'includes/class-massic-options.php';
require_once MASSIC_WP_CONNECTOR_PATH . 'includes/class-massic-http.php';
require_once MASSIC_WP_CONNECTOR_PATH . 'includes/class-massic-security.php';
require_once MASSIC_WP_CONNECTOR_PATH . 'includes/class-massic-content.php';
require_once MASSIC_WP_CONNECTOR_PATH . 'includes/class-massic-head.php';
require_once MASSIC_WP_CONNECTOR_PATH . 'includes/class-massic-preview.php';
require_once MASSIC_WP_CONNECTOR_PATH . 'includes/class-massic-admin.php';
require_once MASSIC_WP_CONNECTOR_PATH . 'includes/class-massic-rest.php';
require_once MASSIC_WP_CONNECTOR_PATH . 'includes/class-massic-connector.php';

function massic_wp_connector_activate() {
    if (!get_option(Massic_Options::OPTION_SITE_ID)) {
        add_option(Massic_Options::OPTION_SITE_ID, wp_generate_uuid4());
    }

    if (!get_option(Massic_Options::OPTION_PAIRING_CODE)) {
        add_option(Massic_Options::OPTION_PAIRING_CODE, wp_generate_password(16, false, false));
    }

    if (!get_option(Massic_Options::OPTION_CLIENT_SECRET)) {
        add_option(Massic_Options::OPTION_CLIENT_SECRET, wp_generate_password(64, false, false));
    }

    if (!get_option(Massic_Options::OPTION_NONCE_TTL)) {
        add_option(Massic_Options::OPTION_NONCE_TTL, 300);
    }

    if (!get_option(Massic_Options::OPTION_LAST_NONCE_CACHE)) {
        add_option(Massic_Options::OPTION_LAST_NONCE_CACHE, '');
    }

    if (!get_option(Massic_Options::OPTION_CONNECTION_STATE)) {
        add_option(Massic_Options::OPTION_CONNECTION_STATE, 'disconnected');
    }

    if (!get_option(Massic_Options::OPTION_CONNECTION_UPDATED_AT)) {
        add_option(Massic_Options::OPTION_CONNECTION_UPDATED_AT, '');
    }
}
register_activation_hook(__FILE__, 'massic_wp_connector_activate');

function massic_wp_connector_deactivate() {
    // Best-effort sync so backend revokes stale active connections when plugin is disabled in WP.
    Massic_Http::notify_plugin_lifecycle('deactivated', gmdate('c'));
    Massic_Options::set_connection_state(false, gmdate('c'));
    Massic_Options::clear_connect_session();
}
register_deactivation_hook(__FILE__, 'massic_wp_connector_deactivate');

function massic_wp_connector_add_settings_link($links) {
    if (!current_user_can('manage_options')) {
        return $links;
    }

    $settings_url = admin_url('options-general.php?page=massic-wp-connector');
    $settings_link = '<a href="' . esc_url($settings_url) . '">' . esc_html__('Settings', 'massic-wp-connector') . '</a>';
    array_unshift($links, $settings_link);

    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'massic_wp_connector_add_settings_link');

function massic_wp_connector_load_textdomain() {
    load_plugin_textdomain('massic-wp-connector', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'massic_wp_connector_load_textdomain');

function massic_wp_connector_add_privacy_policy_content() {
    if (!function_exists('wp_add_privacy_policy_content')) {
        return;
    }

    $content = '<p>' . esc_html__('Massic WP Connector connects this WordPress site to Massic services when an administrator authorizes the connection. The plugin stores connector credentials in WordPress options and may store Massic SEO metadata, featured image metadata, preview tokens, and other Massic-managed post metadata for content published through Massic.', 'massic-wp-connector') . '</p>';
    $content .= '<p>' . esc_html__('When connected, WordPress may send Massic the site URL, site ID, site name, connection state, signed request metadata, lifecycle events, theme/style information, logo or site icon URLs, sample content URLs, and publishing status details. Massic may send WordPress content titles, slugs, statuses, HTML content, SEO metadata, CSS overrides, featured image references, preview requests, slug checks, and unpublish requests.', 'massic-wp-connector') . '</p>';
    $content .= '<p>' . sprintf(
        /* translators: 1: Massic privacy policy URL. 2: Massic terms URL. */
        esc_html__('This data is used to authenticate connector requests, publish and manage customer-authorized content, provide previews, synchronize connection state, and secure the service. See the Massic privacy policy at %1$s and terms at %2$s.', 'massic-wp-connector'),
        '<a href="https://massic.io/privacy">https://massic.io/privacy</a>',
        '<a href="https://massic.io/terms">https://massic.io/terms</a>'
    ) . '</p>';

    wp_add_privacy_policy_content(__('Massic WP Connector', 'massic-wp-connector'), wp_kses_post($content));
}
add_action('admin_init', 'massic_wp_connector_add_privacy_policy_content');

function massic_wp_connector_boot() {
    $plugin = new Massic_Connector();
    $plugin->init();
}
add_action('plugins_loaded', 'massic_wp_connector_boot');
