<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

if (!defined('MASSIC_BACKEND_BASE')) {
    define('MASSIC_BACKEND_BASE', 'https://agency.massic.io');
}

if (!defined('MASSIC_APP_BASE')) {
    define('MASSIC_APP_BASE', 'https://app.massic.io');
}

$massic_plugin_root = dirname(__FILE__);
require_once $massic_plugin_root . '/includes/class-massic-options.php';
require_once $massic_plugin_root . '/includes/class-massic-http.php';

// Best-effort sync: notify backend that plugin was uninstalled so connection can be revoked.
Massic_Http::notify_plugin_lifecycle('uninstalled', gmdate('c'));

delete_option('massic_site_id');
delete_option('massic_pairing_code');
delete_option('massic_client_secret');
delete_option('massic_nonce_ttl');
delete_option('massic_last_nonce_cache');
delete_option('massic_connection_state');
delete_option('massic_connection_updated_at');
delete_option('massic_backend_base');
delete_option('massic_app_base');

delete_transient('massic_connect_session');
